# e& CX SMS Copy — Before / After

**Description:** Description: Approved before/after rewritten SMS copy examples for e& B2C communications including bill reminders, payment confirmations, service suspensions, roaming, OTPs, recharges, and Smiles points. Includes high-priority most-sent templates. English and Arabic versions.

---

## SMS Templates

### SMS 1

**BEFORE**

Dear Customer, 
Your $offer_name$ on your $service_name$ will expire on $date$. Your monthly charges will be AED $charges$ and you will continue to enjoy $benefits_list$.

Thank you for choosing e&.

**AFTER — English**

Hello <Name>, your $offer_name$ on your $service_name$ expires on $date$. Your new monthly charges will be AED $charges$, and you'll still have $benefits_list$. Learn more in the e& app: <App link>

**AFTER — Arabic**

مرحباً <Name>، ستنتهي صلاحية عرض $offer_name$ على خدمة $service_name$ بتاريخ $date$. وسيتم احتساب رسوم شهرية بقيمة $charges$ درهم، مع استمرار المزايا نفسها: $benefits_list$. اعرف أكثر عبر تطبيق إي آند: <App link>

---

### SMS 2

**BEFORE**

You’re eligible for a refund of an Excess balance in your account <AccountNumber>. Please confirm your information to initiate the refund process at <Link>.

**AFTER — English**

You've got credit in your account <AccountNumber>. Want it refunded? Claim here: <Link>

**AFTER — Arabic**

يتوفَّر لديك رصيد في حساب <AccountNumber>. هل ترغب في استرداده؟ قدّم طلبك هنا: <Link>

---

### SMS 3

**BEFORE**

Dear <Customer>,

Welcome to the $Neo Smart Home_Add-on_Plan name$! Your plan is now active with a 24-month contract. 

Thank you for choosing e&.

**AFTER — English**

Hello <Name>, welcome to $Neo Smart Home_Add-on_Plan name$. Your 24-month plan is now active. Want to check your speed, manage your bills, and more? It's all in the e& app.

Thanks for choosing e&, and enjoy your world of more.

**AFTER — Arabic**

مرحباً <Name>، أهلًا بك في $Neo Smart Home_Add-on_Plan name$. تم تفعيل باقتك لمدة 24 شهراً. يمكنك التحقّق من السرعة، إدارة الفواتير، وأكثر عبر تطبيق واحد.
مع إي آند، دايماً في أكثر. شكراً لاختيارك إي آند.

---

### SMS 4

**BEFORE**

Dear Customer, 
Your "Promise to Pay" commitment deadline has passed, and the payment has not been received.

We inform you that all services have been temporarily suspended for account $account_number$ due to an outstanding balance of AED $amount_due$. To restore your services, please make the payment by visiting etisalat.ae/quickpay. 

Thank you for choosing e&.

**AFTER — English**

Important: Your "Promise to Pay" deadline has passed, but we haven't received your payment. 

Your services for account $account_number$ have now been temporarily suspended, because of your outstanding balance of AED $amount_due$.

Pay now to reconnect and enjoy e&: etisalat.ae/quickpay.

**AFTER — Arabic**

تنبيه هام: لقد انتهت مهلة الدفع (Promise to Pay) دون استلام المبلغ.
تم إيقاف خدمات الحساب $account_number$ مؤقتاً، بسبب الرصيد المستحق بقيمة $amount_due$ درهم.
ادفع الآن لإعادة الاتصال والاستمتاع بخدمات إي آند: etisalat.ae/quickpay

---

### SMS 5

**BEFORE**

Dear $Name$, your account $Number$ has been cancelled upon your request. You will receive email shortly with full details.

**AFTER — English**

Hello $Name$. As requested, we've cancelled your account ($Number$). We'll send you a confirmation email soon. 
Don't forget – you still have XX unused Smiles points: <Link>
/
Remember, we're always here if you ever want to get back in touch.

**AFTER — Arabic**

مرحباً $Name$، تم إلغاء الحساب ($Number$) حسب طلبك. ستتلقى رسالة بريد إلكتروني للتأكيد قريباً.
لا يزال لديك XX نقطة Smiles غير مستخدمة: <Link>

يسعدنا خدمتك مجدداً في أي وقت.

---

### SMS 6

**BEFORE**

The reported issue for the account <Acc> has been resolved. To view your fault resolution report, please visit <Link>

**AFTER — English**

Good news – we've fixed the issue on your account <Acc>. Read the full report here <Link>

**AFTER — Arabic**

تم حل المشكلة في حسابك <Acc>. اعرف أكثر عبر التقرير الكامل هنا: <Link>

---

### SMS 7

**BEFORE**

Dear Customer, your bill of AED $amount_due$ for account $account_number$ is due on $due_date$. Please pay now at www.etisalat.ae/quickpay
If you have already paid, please ignore this message.

**AFTER — English**

Hello there, your bill of AED $amount_due$ for account $account_number$ is due on $due_date$. Pay now in a few taps through the e& app, or at www.etisalat.ae/quickpay.

Already paid? Ignore this message.

**AFTER — Arabic**

مرحباً، هناك فاتورة مستحقة السداد لحسابك بقيمة $amount_due$ درهم، وذلك بتاريخ $due_date$. يمكنك السداد الآن عبر تطبيق إي آند أو عبر: www.etisalat.ae/quickpay
في حال تم السداد، يرجى تجاهل هذه الرسالة.

---

### SMS 8

**BEFORE**

Dear Customer, your bill of AED $amount_due$ for account $account_number$ is due today. Please pay now at www.etisalat.ae/quickpay_x000B_If you have already paid, please ignore this message.

**AFTER — English**

Hello there, your bill of AED $amount_due$ for account $account_number$ is due today. Please pay now in the e& app.

Already paid? Ignore this message.

**AFTER — Arabic**

مرحباً، فاتورة حسابك مستحقة اليوم بقيمة $amount_due$ درهم على الحساب $account_number$. سددها الآن عبر تطبيق إي آند.
في حال تم السداد، يرجى تجاهل هذه الرسالة.

---

### SMS 9

**BEFORE**

Dear Customer, your bill of AED $amount_due$ for account $account_number$ is overdue. To continue enjoying your services, please make a payment now at www.etisalat.ae/quickpay_x000B_If you have already paid, please ignore this message.

**AFTER — English**

Important: your bill of AED $amount_due$ for account $account_number$ is overdue. Pay now in the e& app to stay connected.

Already paid? Ignore this message.

**AFTER — Arabic**

تنبيه هام: فاتورة حسابك $account_number$ متأخرة عن السداد بقيمة $amount_due$ درهم. سددها الآن عبر تطبيق إي آند للاستمرار في استخدام الخدمة.
في حال تم السداد، يُرجى تجاهل هذه الرسالة.

---

### SMS 10

**BEFORE**

Dear Customer, your bill of AED $amount_due$ for account $account_number$ is overdue. To avoid interruptions to your services and negative impact to your credit score with AECB, please make a payment now at www.etisalat.ae/quickpay._x000B_If you have already paid, please ignore this message.

**AFTER — English**

Important: your bill of AED $amount_due$ for account $account_number$ is still outstanding. Not paying may affect your services, and even your credit score. Pay now in the e& app.

Already paid? Ignore this message.

**AFTER — Arabic**

تنبيه هام: لا تزال فاتورة حسابك بقيمة $amount_due$ درهم غير مسددة. قد يؤثر عدم السداد على خدماتك وتقييمك الائتماني. سدّدها الآن عبر تطبيق إي آند.
في حال تم السداد، يُرجى تجاهل هذه الرسالة.

---

### SMS 11

**BEFORE**

Congratulations! You have subscribed to our Special Roaming Daily Data Offer successfully, you have been charged AED 17.50 (VAT not applicable) for one-time. Enjoy 500MB data for 24 hours starting from your first use with our preferred partners, check here for more details: www.etisalat.ae/preferredroamingpartners .To manage your add-ons, please visit www.etisalat.ae/manage

**AFTER — English**

You've subscribed to Special Roaming Daily Data Offer for AED 17.50 (excl. VAT)! Enjoy 500MB for 24 hours, which starts as soon as you use data abroad with one of our partners. 

Learn more at www.etisalat.ae/preferredroamingpartners. Or manage your add-ons in the e& app. Thanks for choosing e&.

**AFTER — Arabic**

تم الاشتراك في عرض البيانات اليومي للتجوال الخاص بقيمة 17.50 درهم (غير شامل ضريبة القيمة المضافة). استمتع بـ 500MB لمدة 24 ساعة، تبدأ المدة فور استخدام البيانات أثناء التجوال مع أحد شركائنا.
اعرف أكثر عبر: www.etisalat.ae/preferredroamingpartners أو يمكنك إدارة الإضافات عبر تطبيق إي آند. شكراً لاختيارك إي آند.

---

## Most Sent SMS Templates

### Most Sent SMS 1

**BEFORE**

Your subscription request cannot be completed due to low balance in your account. Kindly recharge and try again.

**AFTER — English**

Sorry, your balance is too low to subscribe to $ADDON_NAME$ (AED XX/mo). Please recharge and try again: $LINK$

**AFTER — Arabic**

عذراً، رصيدك الحالي غير كافي للاشتراك في $ADDON_NAME$ ($XX درهماً شهرياً). يرجى إعادة تعبئة الرصيد ثم المحاولة مرة أخرى: $LINK$

---

### Most Sent SMS 2

**BEFORE**

Dear customer, your request to subscribe to Daily 1GB local data pack has been completed successfully, and AED 5 (Including 5% VAT) has been debited from your account balance.
Pack is onetime valid for 1 day and data can be used within UAE only. Any unused data post expiry will be fortified. To check your remaining data allowance send DATA to 1010. To manage your subscription visit e& UAE Mobile App.

**AFTER — English**

Your Daily 1GB Local Data Pack is active! Price: AED 5 (inc. VAT). It's valid for 1 day, in the UAE only. Unused data will expire. Check your remaining data and manage everything in the e& app.

**AFTER — Arabic**

تم تفعيل باقة البيانات المحلية اليومية (1GB). الرسوم: 5 دراهم (شامل ضريبة القيمة المضافة). سيتم مصادرة البيانات غير المستخدمة بعد انتهاء صلاحيتها خلال يوم واحد داخل دولة الإمارات فقط. قم بالتحقّق من الرصيد المتبقي وإدارة الباقة عبر تطبيق إي آند.

---

### Most Sent SMS 3

**BEFORE**

You have reached maximum subsription limit for the   $Plan_Name$  .

**AFTER — English**

You’ve reached the maximum subscription limit for $Plan_Name$. Manage your plans, packs, and add-ons in the e& app: $LINK$

**AFTER — Arabic**

تم الوصول إلى الحد الأقصى للاشتراك في $Plan_Name$. يمكنك إدارة باقاتك والإضافات عبر تطبيق إي آند: $LINK$

---

### Most Sent SMS 4

**BEFORE**

Thank you for using e& eRecharge Service. Your mobile account has been top up for $TOPUP_AMOUNT$ from $SPURCE_MERCHANT_ID$ on $TIMESTAMP_OF_TOPUP$ . TxnId: $TRANSACTION_ID$

**AFTER — English**

Thanks for using e& eRecharge. You’ve topped up $TOPUP_AMOUNT$ from $SPURCE_MERCHANT_ID$ on $TIMESTAMP_OF_TOPUP$. TxnId: $TRANSACTION_ID$. New balance: $NEW_BALANCE$

**AFTER — Arabic**

شكراً لاستخدامك إي آند eRecharge. تمت إعادة تعبئة الرصيد $TOPUP_AMOUNT$ من $SPURCE_MERCHANT_ID$ بتاريخ $TIMESTAMP_OF_TOPUP$. رقم العملية: $TRANSACTION_ID$ رصيدك الحالي: $NEW_BALANCE$

---

### Most Sent SMS 5

**BEFORE**

Your account is not active. Kindly activate your line and try again.

**AFTER — English**

Your $ACCOUNT_TYPE$ account ($ACCOUNT_NUMBER$) isn't active. Please activate your line in the e& app within $TIMEFRAME$ and try again: $LINK$

**AFTER — Arabic**

حساب $ACCOUNT_TYPE$ ($ACCOUNT_NUMBER$) غير نشط حالياً. يرجى تفعيل الخط عبر تطبيق إي آند خلال $TIMEFRAME$ ثم المحاولة مرة أخرى: $LINK$

---

### Most Sent SMS 6

**BEFORE**

Sorry, you are not eligible for  $Plan_Name$ .

**AFTER — English**

We’re sorry, but your account isn't eligible for $Plan_Name$. Discover plans for you: $LINK$

**AFTER — Arabic**

حسابك غير مؤهل للاشتراك في $Plan_Name$. قم بالاطلاع على الباقات المتاحة لك هنا: $LINK$

---

### Most Sent SMS 7

**BEFORE**

You cannot subscribe to  $ADDON_NAME$ . as you have an active package that does not coexist with the requested offer.

**AFTER — English**

You can’t add $ADDON_NAME$ right now because your $PACKAGE$ isn’t compatible. Manage your packages in the e& app.

**AFTER — Arabic**

لا يمكن إضافة $ADDON_NAME$ حالياً لعدم توافقها مع باقتك. قم بإدارة باقاتك عبر تطبيق إي آند.

---

### Most Sent SMS 8

**BEFORE**

The requested addon  $ADDON_NAME$  is not available for subscription on your number, please subscribe to the parent plan, then try again. To buy another addon, dial *101# or visit www.etisalat.ae/addon

**AFTER — English**

$ADDON_NAME$ isn’t available on your current plan. Subscribe to a new plan and try again in the e& app.

**AFTER — Arabic**

$ADDON_NAME$ غير متاحة لباقتك الحالية. اشترك في باقة أخرى ثم أعد المحاولة عبر تطبيق إي آند.

---

### Most Sent SMS 9

**BEFORE**

You have exceeded the maximum number of times you can subscribe to $Plan_Name$ .

**AFTER — English**

You've reached the maximum subscription limit for $Plan_Name$. Discover more plans, packs, and add-ons in the e& app.

**AFTER — Arabic**

لقد تم الوصول إلى الحد الأقصى للاشتراك في $Plan_Name$. اطّلع على المزيد من الباقات والإضافات عبر تطبيق إي آند.

---

### Most Sent SMS 10

**BEFORE**

Your balance is getting low. Recharge your account online and get special offers on every recharge at etisalat.ae/recharge . You can also request credit transfer from your friends and family by dialing *107*05XXXXXX*Amount#

**AFTER — English**

Your balance is low. Recharge via the e& app and earn rewards every time. Need a credit transfer from friends or family? You can do that in the app too.

**AFTER — Arabic**

رصيدك غير كافِ. أعد تعبئة الرصيد عبر تطبيق إي آند واستفد من المكافآت في كل مرة. هل تحتاج إلى تحويل رصيد من الأهل أو الأصدقاء؟ يمكنك إتمام ذلك عبر التطبيق أيضاً.

---

### Most Sent SMS 11

**BEFORE**

Dear Customer, Your payment to the account number $ACCOUNT_NUMBER$  has been processed.
Amount Due: AED $DUE_AMOUNT$ 
Amount Paid: AED $PAID_AMOUNT$ 
Remaining Balance: AED $BALANCE_AMOUNT$ 
Transaction Date: $TXN_DATE$ 
Transaction Time: $TXN_TIME$ 
Payment Channel: $PAYMENT_CHANNEL$ 
Card Number: $CARD_NUMBER$ 
Mode of Payment : $MODE_OF_PAYMENT$ 
Transaction #: $TXN_NUMBER$ 
Reference #: $EPG_REFRENCE_NUMBER$ 

To Know your Payment Status through WhatsApp Click on  $WhatsAppURL$

**AFTER — English**

Hello $FIRST_NAME$, thanks for your payment – we've now processed it. Here are the details:

Account number: $ACCOUNT_NUMBER$ 
Amount Due: AED $DUE_AMOUNT$ 
Amount Paid: AED $PAID_AMOUNT$ 
Remaining Balance: AED $BALANCE_AMOUNT$ 
Transaction Date: $TXN_DATE$ 
Transaction Time: $TXN_TIME$ 
Payment Channel: $PAYMENT_CHANNEL$ 
Card Number: $CARD_NUMBER$ 
Mode of Payment: $MODE_OF_PAYMENT$ 
Transaction #: $TXN_NUMBER$ 
Reference #: $EPG_REFERENCE_NUMBER$ 

View your payment status via WhatsApp [$WhatsAppURL$]

**AFTER — Arabic**

مرحباً $FIRST_NAME$، شكراً لإتمام عملية الدفع، تمّ تنفيذها بنجاح. إليك التفاصيل كما يلي:

رقم الحساب: $ACCOUNT_NUMBER$
المبلغ المستحق: $DUE_AMOUNT$
المبلغ المدفوع: $PAID_AMOUNT$ درهم
الرصيد المتبقي: $BALANCE_AMOUNT$ درهم
تاريخ العملية: $TXN_DATE$ درهم
وقت العملية: $TXN_TIME$
قناة الدفع: $PAYMENT_CHANNEL$
رقم البطاقة: $CARD_NUMBER$
طريقة الدفع: $MODE_OF_PAYMENT$
رقم العملية: $TXN_NUMBER$
الرقم المرجعي: $EPG_REFERENCE_NUMBER$

اطّلع على حالة الدفع من خلال WhatsApp: [$WhatsAppURL$]

---

### Most Sent SMS 12

**BEFORE**

AED $amount_due$ due on account no. $AccountNumberWithSuffix$ . To avoid further reminders, pay it online here www.etisalat.ae/quickpay. You can also use our payment machine or call 125 with your account ID $account_id$ . For more assistance, call $DCA_Inbound_Number$ . Please ignore this message if you’ve already paid.

**AFTER — English**

Hello there, your bill for AED $amount_due$ is due soon (Account: $AccountNumberWithSuffix$). Pay in a few clicks in the e& app.

Already paid? Ignore this message.

**AFTER — Arabic**

مرحباً، لديك مبلغ مستحق بقيمة $amount_due$ درهم على الحساب ($AccountNumberWithSuffix$)، وسيحين موعد السداد قريباً. سدد فاتورتك بسهولة عبر تطبيق إي آند.
في حال تم السداد، يُرجى تجاهل هذه الرسالة.

---

### Most Sent SMS 13

**BEFORE**

Dear  $FIRST_NAME$   , we are unable to process your request to add account no $MOBILE_NO$ under your Smiles UAE membership number $CARD_NO$  .  Know more about Smiles at https://smilesuae.ae/appdownload

**AFTER — English**

Sorry, $FIRST_NAME$, we can’t add $MOBILE_NO$ to your Smiles UAE membership $CARD_NO$. Learn more at https://smilesuae.ae/appdownload

**AFTER — Arabic**

عذراً $FIRST_NAME$، لا يمكن إضافة $MOBILE_NO$ إلى عضوية Smiles UAE $CARD_NO$ حالياً. اعرف أكثر عبر: https://smilesuae.ae/appdownload

---

### Most Sent SMS 14

**BEFORE**

Dear $FIRST_NAME$ , Congratulations! You have earned $pts$ points from $partner_name$ for $activity_description$ . Your current points balance is $xxx$ . FREE Delivery on every grocery order from Smiles Market. Order now https://smilesuae.go.link/fNfsU

**AFTER — English**

Congratulations $FIRST_NAME$! You’ve earned $pts$ Smiles Points from $partner_name$ for $activity_description$. Your new balance is $xxx$. You also get free delivery on every grocery order from Smiles Market. Order now: https://smilesuae.go.link/fNfsU

**AFTER — Arabic**

تهانينا $FIRST_NAME$! لقد حصلت على $pts$ نقطة Smiles من $partner_name$ مقابل $activity_description$. رصيدك الحالي: $xxx$. كما ستحصل أيضاً على توصيل مجاني على جميع طلبات البقالة من Smiles Market. اطلب الآن: https://smilesuae.go.link/fNfsU

---

### Most Sent SMS 15

**BEFORE**

Dear $FIRST_NAME$, Great news! You've just earned $TOTAL_POINTS$ usage points and an additional $TIER_BONUS$ tier bonus for your $ACCRUAL_DESCRIPTION$ on account number $MSISDN$. To discover more benefits and rewards, visit the Smiles app today!

**AFTER — English**

Great news, $FIRST_NAME$! You've just earned $TOTAL_POINTS$ Smiles Points and a $TIER_BONUS$ tier bonus for your $ACCRUAL_DESCRIPTION$. Discover more rewards on the Smiles app: https://smilesuae.go.link/fNfsU

**AFTER — Arabic**

خبر سار يا $FIRST_NAME$! لقد حصلت على $TOTAL_POINTS$ نقطة Smiles، بالإضافة إلى مكافأة فئة بقيمة $TIER_BONUS$ مقابل $ACCRUAL_DESCRIPTION$. اكتشف المزيد من المكافآت عبر تطبيق Smiles: https://smilesuae.go.link/fNfsU

---

### Most Sent SMS 16

**BEFORE**

You have not used your prepaid line since $DATE$ . Please start using it today to keep enjoying your validity benefits.

For more details, visit www.etisalat.ae/waselvalidityrulesen.

**AFTER — English**

Hello there, you haven't used your prepaid line since $DATE$. Start today to keep enjoying your service and benefits. Learn more at www.etisalat.ae/waselvalidityrulesen

**AFTER — Arabic**

مرحباً، لم يتم استخدام خطك المدفوع مقدماً منذ $DATE$. استخدم خطك اليوم للحفاظ على الخدمة والاستفادة من المزايا. اعرف أكثر: www.etisalat.ae/waselvalidityrulesen

---

### Most Sent SMS 17

**BEFORE**

Dear $CUSTOMER_FIRSTNAME$, a purchase of $CURRENCY$ $AMOUNT$ was successfully completed at $MERCHANT_NAME$ using your e& money card ending with $LAST_DIGITS_CARD$. 
Date: $DATE_TIME$
You earned AED $REWARD_AMOUNT$ cash rewards with this transaction.
Available balance: AED $AVAILABLE_BALANCE$
Transaction ID: $TRANSACTION_ID$

**AFTER — English**

$CUSTOMER_FIRSTNAME$, you just paid $CURRENCY$ $AMOUNT$ to $MERCHANT_NAME$ with your e& money card ending in $LAST_DIGITS_CARD$. 

You've earned AED $REWARD_AMOUNT$ and your balance is now AED $AVAILABLE_BALANCE$.

Date: $DATE_TIME$
Transaction ID: $TRANSACTION_ID$

**AFTER — Arabic**

$CUSTOMER_FIRSTNAME$، تم تنفيذ عملية دفع $AMOUNT$ $CURRENCY$ لدى $MERCHANT_NAME$ باستخدام بطاقة e& money المنتهية بـ$LAST_DIGITS_CARD$.
لقد حصلت على $REWARD_AMOUNT$ درهم، وأصبح رصيدك الآن $AVAILABLE_BALANCE$ درهم.
التاريخ: $DATE_TIME$
رقم العملية: $TRANSACTION_ID$

---

### Most Sent SMS 18

**BEFORE**

Hey $SENDER_NAME$! 
Your transfer of AED $AMOUNT$ is initiated. 
You'll get an alert when $RECEIVER_NAME$ receives the amount of $FX_CURRENCY$ $RECEIVE_AMOUNT$ in their $BANK_NAME$ account. 
Your $PARTNER_NAME$ reference number: $MG_REFERENCE_NUMBER$

**AFTER — English**

$SENDER_NAME$, you’ve sent AED $AMOUNT$ ($FX_CURRENCY$ $RECEIVE_AMOUNT$) to $RECEIVER_NAME$. We'll let you know when it arrives. 
$PARTNER_NAME$ reference: $MG_REFERENCE_NUMBER$

**AFTER — Arabic**

$SENDER_NAME$، تم إرسال $AMOUNT$ درهم ($FX_CURRENCY$ $RECEIVE_AMOUNT$) إلى $RECEIVER_NAME$. سنقوم بإبلاغك عند وصول المبلغ. الرقم المرجعي $PARTNER_NAME$: $MG_REFERENCE_NUMBER$

---

### Most Sent SMS 19

**BEFORE**

Woohoo, $SENDER_NAME$ 
Your transfer is done! 
$RECEIVER_NAME$ received $FX_CURRENCY$ $RECEIVE_AMOUNT$ successfully! 
Seamless and successful – just how we like it! 
Your $PARTNER_NAME$ reference number: $MG_REFERENCE_NUMBER$

**AFTER — English**

Transfer successful! $RECEIVER_NAME$ just got $FX_CURRENCY$ $RECEIVE_AMOUNT$. 

$PARTNER_NAME$ reference: $MG_REFERENCE_NUMBER$

Thanks for using e& Money.

**AFTER — Arabic**

تمت عملية التحويل بنجاح! استلم $RECEIVER_NAME$ مبلغ $FX_CURRENCY$ $RECEIVE_AMOUNT$.
الرقم المرجعي $PARTNER_NAME$: $MG_REFERENCE_NUMBER$
شكراً لاستخدامك e& money.

---

### Most Sent SMS 20

**BEFORE**

<#> $CODE$  is the security code. This is a One-Time Password (OTP) from the e& UAE Portal/Mobile App that will grant you access to manage or allow the purchase of service on your account/s. Do not disclose this to anyone as your account can be compromised. If you’ve not requested this, please contact us on 101.0rkaqIiy6Fg

**AFTER — English**

Here's your one-time password for the e& app: $CODE$. Never share this code. Didn't request a code? Call us now on 101.

**AFTER — Arabic**

إليك رمز التحقق لتطبيق إي آند: $CODE$ لا تشارك هذا الرمز مع أي شخص. إذا لم تطلب هذا الرمز، اتصل بنا فوراً على 101.

---

### Most Sent SMS 21

**BEFORE**

Welcome to Oman. Stay connected with your loved ones with ease. Dial *177# to get a 500MB mobile internet data roaming pack for just AED 35 per day. To view other roaming packages with voice options as well, and to check standard roaming rates and more information, dial *177# or order through e& UAE app (Consumer) or e& UAE Business app (Business). We wish you a great stay

**AFTER — English**

Welcome to Oman. Dial *177# for 500MB (AED 35/day) to get you started. Then go to "add-ons" in the e& app to discover our Roam Like Home packs, rates, and more. If you have a business account, you can manage roaming in the e& Business app. 

Enjoy Oman with e&.

**AFTER — Arabic**

مرحباً بك في عُمان.
اطلب *177# للحصول على 500MB مقابل 35 درهماً يومياً.
لاكتشاف باقات تجوّل كأنك في دارك والأسعار وأكثر، افتح صفحة الإضافات في تطبيق إي آند. وإذا كان لديك حساب أعمال، يمكنك إدارة التجوال عبر تطبيق e& Business.
استمتع بإقامتك في عُمان مع إي آند.

---
