# Arabic Glossary — Brand Language

**Description:** Approved Arabic translations for e& brand names, plan names, product names, and add-on names. Includes rules on which terms to keep in English.

---

## Table of Contents

- [Brand](#brand)
- [Plan Names — Business](#plan-names--business)
- [Plan Names — Consumer](#plan-names--consumer)
- [Add-ons — Consumer](#add-ons--consumer)
- [Products / Services](#products--services)

---

## Brand

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| e& | إي آند | When referring to the e& app, then write "e&" as is in English | |
| e& group | مجموعة إي آند | | |

---

## Plan Names — Business

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Business plan | باقة الأعمال | plans designed for business customers | |
| Business Xtreme | Business Xtreme | Branded plan name. Kept in English. | |

---

## Plan Names — Consumer

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Freedom plan | باقة Freedom | Branded plan name. Kept in English. | |
| Wasel Flexi | Wasel Flexi | Branded plan name. Kept in English. | |

---

## Add-ons — Consumer

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| 1GB Data | 1GB بيانات | | |
| 5GB Data | 5GB بيانات | | |
| 12GB Data | 12GB بيانات | | |
| 20GB Data | 20GB بيانات | | |
| 35GB Data | 35GB بيانات | | |
| 70 International Minutes | 70 دقيقة دولية | | |
| 150 International Minutes | 150 دقيقة دولية | | |
| 350 International Minutes | 350 دقيقة دولية | | |
| 600 International Minutes | 600 دقيقة دولية | | |
| 120 Local Minutes | 120 دقيقة محلية | | |
| 240 Local Minutes | 240 دقيقة محلية | | |
| 500 Local Minutes | 500 دقيقة محلية | | |
| 800 Local Minutes | 800 دقيقة محلية | | |
| Carryforward Local Minutes | ترحيل الدقائق المحلية | | |
| 60 SMS | 60 رسالة نصية | | |
| 100 SMS | 100 رسالة نصية | | |
| 300 SMS | 300 رسالة نصية | | |
| 500 SMS | 500 رسالة نصية | | |
| 1000 SMS | 1000 رسالة نصية | | |
| Daily Data for emails for 1 Month | بيانات يومية للبريد الإلكتروني لمدة شهر | | |
| Daily Data for emails for 6 Months | بيانات يومية للبريد الإلكتروني لمدة 6 أشهر | | |
| Daily Data for emails for 12 Months | بيانات يومية للبريد الإلكتروني لمدة 12 شهرًا | | |
| Daily Collaborations for 1 Month | تعاون يومي لمدة شهر | | |
| Daily Collaborations for 6 Months | تعاون يومي لمدة 6 أشهر | | |
| Daily Collaborations for 12 Months | تعاون يومي لمدة 12 شهرًا | | |
| Daily Data Plan | باقة البيانات اليومية | | |
| Daily Combo Plan | باقة كومبو اليومية | | |
| Weekly Combo Pack | باقة كومبو الأسبوعية | | |
| Economy Class Pack | باقة الدرجة السياحية | | |
| Business Class Pack | باقة درجة الأعمال | | |
| First Class Pack | باقة الدرجة الأولى | | |
| Non Stop India Roaming Pack | باقة تجوال Non Stop للهند | | |
| Weekly Roaming Voice Plan | باقة مكالمات التجوال الأسبوعية | | |
| Monthly Roaming Voice Pack | باقة مكالمات التجوال الشهرية | | |
| Daily Roaming Voice Pack | باقة مكالمات التجوال اليومية | | |
| 10GB Weekly Roaming Data | 10GB بيانات تجوال أسبوعية | | |
| Roam Like Home Data Pack | باقة بيانات تجوّل كأنك في دارك | | |
| 35GB Roaming Data | 35GB بيانات تجوال | | |
| 50GB Roaming Data | 50GB بيانات تجوال | | |
| Roaming Combo Pack | باقة كومبو للتجوال | | |
| 10GB Business Weekly Roaming Data Pack | 10GB باقة بيانات تجوال الأعمال الأسبوعية | | |
| 2GB Weekly Roaming Data Pack | 2GB باقة بيانات تجوال الأسبوعية | | |
| 10GB Weekly Roaming Data | 10GB بيانات تجوال أسبوعية | | |
| 2GB Weekly Roaming Data | 2GB بيانات تجوال أسبوعية | | |
| Umrah and Haj Pack | باقة العمرة والحج | | |
| 20GB Weekly Roaming Data | 20GB بيانات تجوال أسبوعية | | |
| 7GB Weekly Roaming Data | 7GB بيانات تجوال أسبوعية | | |
| 1GB Daily Roaming Data | 1GB بيانات تجوال يومية | | |
| 3GB Roaming Data | 3GB بيانات تجوال | | |
| 5GB GCC Roaming Data | 5GB بيانات دول مجلس التعاون الخليجي | | |
| 15GB GCC Roaming Data | 15GB بيانات دول مجلس التعاون الخليجي | | |
| 20GB Roaming Data | 20GB بيانات تجوال | | |
| New Umrah and Haj Pack | باقة العمرة والحج الجديدة | | |
| 100 Minutes Incoming Roaming | 100 دقيقة مكالمات تجوال واردة | | |
| Non stop Incoming Minutes Pack | باقة Non stop للدقائق الواردة | | |

---

## Products / Services

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| GoChat | GoChat | | |
| Travel Insurance | تأمين السفر | | |
| Home Wireless Premium | Home Wireless Premium | Kept in English. | |
| Parental control | الإشراف الأبوي | | |
| Premium number | الرقم المميز | | |
| Gold number | الرقم الذهبي | | |
| Platinum number | الرقم البلاتيني | | |
| Social Plus Data | بيانات Social Plus | | |
| Home Move | نقل الخدمة المنزلية | | |
| Home Services | الخدمات المنزلية | Previously "eLife" | |
| Home Plans | الباقات المنزلية | | |
| Home Wireless | Home Wireless | Kept in English. | |