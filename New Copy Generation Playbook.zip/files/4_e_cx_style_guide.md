# Style guide

This style guide contains the stylistic elements that reflect our brand. From how to write numbers to when to use hyphens.

---

## Abbreviations and acronyms

1. If there's space, explain uncommon acronyms and abbreviations on first use: B1G1 (Buy-1-get-1)
2. Don't use periods: UAE not U.A.E
3. Use familiar abbreviations and acronyms where possible

---

## Bullet points

1. Capitalise the first word after each bullet point
2. Don't use a period if the bullet point is a sentence fragment or a single sentence
3. Do use periods if the bullet point is two or more sentences

---

## Calls to action (CTAs)

1. Start CTAs with imperative verbs: Discover, Explore, Buy

---

## Capitalisation

1. Capitalise proper nouns (names, organisations, plans, places, business units, etc.)
2. Capitalise months and days of the week, but not seasons
3. Don't capitalise words for effect: Free not FREE

---

## Conjunctions

1. Starting a sentence with "And" or "But" is okay, but do it sparingly

---

## Contractions

1. Use contractions (eg "don't", "we're"). They help our writing sound more natural, and conversational.

---

## Currency

1. Ð is our default currency
   a. Put it before the number: Ð250 not 250Ð
   b. Use the symbol, not the abbreviation
   c. Do not add a space between the symbol and the number
2. For other currencies, use the abbreviation
3. If there's space, make it clear if a price includes VAT or not

---

## Dates and times

1. Write dates in DMY format: 31 July 2025
2. Avoid slashes (eg 31/07/2025) unless space is tight
3. Use the 12-hour clock with am/pm: 9:00am or 9am
4. In push notifications or app UI, abbreviate dates: Offer ends 31 Aug
5. Include time zone only if relevant

---

## e&

1. Always refer to the brand as "e&", never "Etisalat"

---

## Emirati culture

1. Avoid slang, idioms, and humour that may not translate well
2. Respect cultural norms and values
3. Avoid references that assume a Western point of view

---

## Greetings

1. When you can't personalise, use: Hello there,
2. When you can personalise, use: Hello $FIRST_NAME$ or $FIRST_NAME$
3. When you can personalise and you're writing to Emirati or Business customers, use: Dear $FIRST_NAME$

---

## Hyphens and dashes

1. Use a hyphen (-) to connect compound words: Hassle-free, In-app support
2. Use an en dash (–) for ranges: 10am–2pm
3. Use an en dash (–) with a space either side for emphasis or a longer pause: Register – we'll do the rest.
   a. Use sparingly
   b. Limit use in tight space (eg SMS)

---

## Measurements

1. Use the metric system
2. Use numerals for all measurements: 5GB, 100Mbps
3. Use abbreviations: 500MB not 500 megabytes
4. Don't add a space between the number and abbreviation: 500MB not 500 MB

---

## Numbers

1. Spell out one to nine, and use numerals from 10 onwards
2. Always use numerals with units or data: 3GB, 5 minutes

---

## Personalisation

1. Use the customer's name if possible
2. Don't use names more than once per message
3. Always address the reader directly: You're almost out of data

---

## Phone numbers

1. Separate phone numbers with spaces, not periods or hyphens: 05 677 11508
   (Standard type. Example phone number should be in italic font.)

---

## Punctuation

1. Use common punctuation
2. Only use exclamation marks in SMS. Do not overuse.
3. Use ellipses (...) sparingly
4. Use one space after a period
5. Only use ampersands in names (eg e&), not as a substitute for "and"
6. Only capitalise the first word after a colon if it's a proper noun or the start of a complete sentence
7. Use serial commas for clarity: Mobile, TV, and laptops
8. Don't use a period for headlines with one sentence
9. Do use a period for headlines with two sentences
10. Keep headlines to 10 words or fewer

---

## Sentence length

1. Keep sentences under 20 words

---

## Spelling

1. Use British English spelling (eg optimise, organise, colour, centre)

---

## URLs

1. Keep URLs short and relevant
2. Use bit.ly, especially for SMS and push notifications
3. Don't hyperlink full sentences – only the most relevant part (~1–3 words)