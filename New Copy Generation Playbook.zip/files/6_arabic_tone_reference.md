# e& Arabic — Tone & Writing Style Reference

**Purpose:** Reference for writing on-voice Arabic CRM and promo copy.
**Source:** Distilled from live eand.ae / etisalat.ae Arabic consumer pages (Freedom, Emirati Freedom, New Freedom, billed-plan offer copy). Patterns below are observed from real published e& Arabic, not invented.
**Use:** Consult before writing Arabic. Match the *shape and register* of these patterns — do not copy phrases verbatim into unrelated offers.

---

## 1. The core voice in one line

e& Arabic promo copy is **warm formal MSA, second person, benefit-first, verb-led.** It invites, it does not announce. It speaks *to* the customer ("استمتع", "احصل على", "تحدث براحتك"), never *about* the company ("أعلنت إي آند"). If a line sounds like a press release or a translated English sentence, it is off-voice.

---

## 2. How real e& Arabic opens a benefit

e& almost always opens on an imperative benefit verb, second person. Observed openers from live copy:

- استمتع بـ… (enjoy…) — the single most common e& opener
- احصل على… (get…)
- تمتع بـ… (have full…)
- تحدث… / ابقَ على اتصال… (talk… / stay connected…)
- اختر… (choose…)
- استفد من… (make use of…)
- اكتشف… (discover…)

Real examples (verbatim from live pages, for register reference):
- «استمتع بأروع قيمة وأسرع تغطية للبيانات»
- «احصل على أفضل أسعار الدقائق، البيانات والرسائل النصية القصيرة»
- «تمتع بكامل الحرية مع باقات إماراتي Freedom»
- «ابقَ على اتصال دائم مع أحبائك وتحدث براحتك»
- «اختر باقتك بحسب احتياجاتك»

**Pattern:** verb → benefit → (offer detail). Never open on what the customer lacks.

---

## 3. What e& Arabic never does (anti-patterns)

These are the things that make copy read as translated-from-English or off-brand. Avoid all:

- **Scarcity / loss openers.** e& opens on gain, never on "your data is running out". No «بياناتك تنتهي» / «لا تدع…» as a first line.
- **Third-person announcement voice** in customer copy. «أعلنت إي آند», «تكشف», «تحقق» belong to press releases, not CRM.
- **Support-desk phrasing** in a promo. No «نحن هنا للمساعدة», «رتّب أمرك».
- **English-style fragment headlines.** e& headlines carry a verb and a full thought. No «العطلة قادمة. لا تنفد من البيانات.» comma-fragment stacking.
- **Insurance/safety framing** for data. No «مؤمّنة» / «محمية» for an offer.
- **Word-for-word mirroring** of English clause order. Arabic leads with the verb; restructure, don't transpose.

---

## 4. Sentence construction that reads native

- **Verb-first (VSO)** is the default for promos. Noun-first only when the number *is* the hook: «50GB بيانات إضافية دون أي تكلفة إضافية».
- **One idea per sentence.** Where English stacks with a dash or semicolon, split into two Arabic sentences.
- **Stack benefits with a linking phrase**, the way e& does: «بالإضافة إلى…», «إلى جانب…», «مع…». Real: «استمتع بتفعيل بطاقة SIM مجاناً، بالإضافة إلى خصومات حصرية».
- **Warmth comes from the reader's world, not adjectives:** «أحبائك», «راحتك», «احتياجاتك», «كما تشاء». e& personalises by referencing the customer's life, not by piling on descriptors.

---

## 5. Conventions (as used on live consumer pages)

- **Numerals: Latin digits** in consumer copy — «125 درهم», «50GB», «40%», «2500 دقيقة». (Arabic-Indic numerals ١٢٥ appear only in press/formal registers — do not use in CRM.)
- **Currency: numeral + درهم.** «125 درهم», «225 درهم». For a plural count 3–10 use «دراهم» («10 دراهم»). Never a bare «بـ 10 درهم» — phrase it «بقيمة 10 دراهم» or «مقابل 10 دراهم».
- **Data units stay Latin:** «50GB», «10GB» — not «جيجابايت» in CRM copy.
- **Product names stay English:** Freedom, Emirati Freedom, Wasel, Business Xtreme, Weekend Data Booster. e& = «إي آند».
- **Postpaid = خط الفاتورة. Prepaid = واصل / الدفع المقدم.**
- **Diacritics only to disambiguate** («فعّل», «تمتّع», «مرِنة»). Do not fully vocalise.
- **CTA verbs, imperative present:** «فعّل الآن», «اشترك الآن», «اكتشف الآن», «اختر باقتك». Avoid «انقر هنا» / «اضغط للتفعيل».

---

## 6. Register calibration (one axis, not a rule per channel)

e& Arabic sits on a single warm-formal MSA spine. The only thing that shifts by surface is **length and density**, not voice:

- **Short surfaces (push, SMS):** one benefit, one verb, one number. Trim linking clauses.
- **Longer surfaces (email, web):** same voice, room for a second benefit and a soft close.

The tone — inviting, second person, benefit-led — stays identical across all of them. Do not switch to a colder or more corporate register for email, or a slangier one for push.

---

## 7. The two tests before any Arabic ships

1. **Back-translation test:** if the line maps word-for-word back to an English sentence, it's a translation, not e& Arabic. Rewrite from the offer facts.
2. **Native test:** could this exact line sit on an eand.ae consumer offer page next to «استمتع بأروع قيمة» and «تمتع بكامل الحرية»? If it reads like an announcement or a rendering, rewrite.

---

*Reference compiled from live e& / Etisalat UAE Arabic consumer pages (Freedom, Emirati Freedom, New Freedom, billed-plan offer and benefits pages). Verbatim examples are quoted only as register anchors.*
