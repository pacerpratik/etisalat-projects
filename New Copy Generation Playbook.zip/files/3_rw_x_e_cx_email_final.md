# e& CX Email Copy — Before / After

**Description:** Description: Approved before/after rewritten email copy examples for e& B2C communications including offer expiry, billing, service suspension, device protection, and smart home. Includes subject lines, headers, body copy, and CTAs in English and Arabic.

---

## Email 1

### BEFORE

Subject:        Your Account`s Offer is Nearing to Expire
Account Number: DD, MM, YYY
Header:         Your Offer will Expire Soon
Para 1:        Dear Customer,        We want to inform you that your current $Offer Name$ benefits package for your $Service Name$ will expire on $Date$.
Para 2:        Post-Expiration Details:
         Benefits: $List of benefits$
         Monthly Fee: AED $Monthly Price$
Para 3:        To ensure uninterrupted service and continue enjoying your benefits, please take action before the expiration date. 
You can easily manage your account through $e& UAE app$
Para 4:        View & pay your bill easily on the e& UAE app DOWNLOAD NOW
Footer: Copyright 2024 @ e&. All Rights Reserved. This is an auto generated email sent by our system. Please do not reply to this email.

### AFTER — English

Subject:        
Don't forget – your offer expires soon

Account number: 
(Acc. Number: DD, MM, YYYY)

Header:         
A world of more is waiting

Body:      
Hello there,      

Just so you know, your $Offer Name$ benefits package for your $Service Name$ will expire on $Date$.

Once it's expired, your plan will cost AED $Monthly Price$/month, and have these benefits:

$List of benefits$

You can manage your plan, benefits, and more in the e& app.
 
App line:        
Not got the e& app? Download now

Footer: Copyright 2024 @ e&. All Rights Reserved. This is an auto generated email sent by our system. Please do not reply to this email.

### AFTER — Arabic

لا تفوّت الفرصة، سينتهي العرض قريباً

رقم الحساب:
(Acc. Number: DD, MM, YYYY)

دايماً في أكثر مما تتوقع

 مرحباً،

نودّ تذكيرك بانتهاء صلاحية مزايا باقة $Offer Name$ الخاصة بخدمة $Service Name$ بتاريخ $Date$.

بعد انتهاء العرض، سيتم احتساب الاشتراك بقيمة $Monthly Price$ درهماً شهرياً، مع المزايا التالية:

 $List of benefits$ 

يمكنك إدارة باقتك، المزايا وأكثر بسهولة عبر تطبيق إي آند.

حمّل تطبيق إي آند الآن

© 2024 إي آند. جميع الحقوق محفوظة. تم إرسال هذا البريد الإلكتروني تلقائياً. يرجى عدم الرد عليه.

---

## Email 2

### BEFORE

Header: What to expect from your first bill
Account Number: < Acc>
DD, MM, YYYY
Your first bill is almost here!
Dear Customer,
Your first e& bill for account number <Number> will be issued on the 1st of every month. 
To help you understand your first bill, we have created a short video showing how you to read your bill, first month charges explained, applicable promotions, and bill payment guidance.
Add Video
{H1} Important Notes About Your First Bill
{H2} Pro-Rata Charges
Your first bill will be pro-rated to reflect the actual days of service used during the month. This means you will only be charged for the days from when your service was first activated.
How Does Pro-Rating Work?
If you subscribed to a plan costing AED 150 per month on November 16th. Your pro-rata charges for the month of November will be calculated as follows:
Please note that pro-rated fees are calculated assuming a 30-day month. Actual charges will vary based on the specific number of days in the billing months and your service activation date.
{H2} Rental Discounts 
If you subscribed using any promotional offers or discounts, then the Rental discounts will be applied from your 2nd month to maximize your promotion benefits.
Understand your e& bill with the Bill Explainer tool. Visit Bill Explainer
To know more about the other payment channels, please visit this link 
To manage your account, bill payments, account recharge, data sharing, and more ...
Download e& UAE app
IOS           Android
Thank you for choosing e&. Hope to see you again.
e& UAE app links
Have a good day
Copyright 2024 @ e&. All Rights Reserved. This is an auto generated email sent by our system. Please do not reply to this email

### AFTER — English

[FIRST EMAIL]

Subject:
Your first bill is on its way – here's what you need to know

Header:
What to expect from your first bill

Account Number:
(Acc. Number: DD, MM, YYYY)

Hello there, 

Your first bill is on its way. We'll issue it at the start of every month, and it will reflect your previous month's charges.

To help you understand your first bill, watch the short video below. It explains first month charges, how to ready your bill, how you can apply promotions, and the easiest ways to pay. 

[VIDEO]

[SECOND EMAIL]

Subject:
Your guide to pro-rata charges

Header:
What you need to know

Account Number:
(Acc. Number: DD, MM, YYYY)

Hello there,

Your first bill will only reflect the days you use your plan. You won't be charged for any days before your plan is activated. Here's an example:

[EXAMPLE]

We also calculate daily rates using a typical 30-day month. But because actual months can be longer or shorter, and depending on when you activate your plan, your daily charges may vary slightly. Don't worry – your monthly cost hasn't changed.

[THIRD EMAIL]

Subject:
Your guide to subscription discounts

Header:
What you need to know

Account Number:
(Acc. Number: DD, MM, YYYY)

Hello there,

If you subscribed to e& using a promotional offer or discount, we'll apply this from your first full month. That way you get the most from the offer.

And remember, you can manage your account, plan, benefits, and more in the e& app. You can also automate your payments with Autopay. Not got the app? Download now [$Link$]

Learn more about your e& bill with our Bill Explainer tool [$Link$]

Footer of all emails:
Thank you for choosing e&. Welcome to a world of more.
Copyright 2025 @ e&. All Rights Reserved. This is an auto generated email sent by our system. Please do not reply to this email

### AFTER — Arabic

[FIRST EMAIL]
Subject:
فاتورتك الأولى قيد الإصدار 
رقم الحساب:
(Acc. Number: DD, MM, YYYY)
إليك كل ما تحتاج معرفته عن فاتورتك الأولى
مرحباً،
فاتورتك الأولى قيد الإصدار، وسيتم إصدارها في بداية كل شهر، لتعكس الرسوم المستحقة عن الشهر السابق.
ولمساعدتك في الاطلاع على تفاصيل فاتورتك الأولى وفهمها بشكل أوضح، يمكنك مشاهدة الفيديو القصير أدناه، حيث يشرح:
رسوم الشهر الأول
طريقة الاطلاع على الفاتورة
كيفية الاستفادة من العروض الترويجية
أسهل طرق السداد
[VIDEO]
شكراً لاختيارك إي آند.
© 2025 إي آند. جميع الحقوق محفوظة.
تم إرسال هذا البريد الإلكتروني تلقائياً، يرجى عدم الرد عليه.
[SECOND EMAIL]
Subject:
آلية احتساب الرسوم حسب مدة الاستخدام
رقم الحساب:
(Acc. Number: DD, MM, YYYY)
إليك كيفية احتساب الرسوم في فاتورتك الأولى
مرحباً،
ستتضمن فاتورتك الأولى الرسوم الخاصة بالأيام التي استخدمت فيها باقتك فقط، ولن يتم احتساب أي رسوم عن الفترة التي سبقت تفعيل الاشتراك.
فيما يلي مثال توضيحي:
[EXAMPLE]
يتم احتساب المعدل اليومي للرسوم على أساس  30 يوماً في الشهر، ونظراً لاختلاف عدد أيام الأشهر ، أو بحسب تاريخ تفعيل باقتك، قد يظهر فرق بسيط في قيمة الرسوم اليومية.
لكن لا داعي للقلق، فقيمة اشتراكك الشهرية ثابتة ولم تتغير.
شكرًا لاختيارك إي آند.
© 2025 إي آند. جميع الحقوق محفوظة.
تم إرسال هذا البريد الإلكتروني تلقائياً، يرجى عدم الرد عليه.
[THIRD EMAIL]
Subject:
كيفية تطبيق الخصومات على اشتراكك
رقم الحساب:
(Acc. Number: DD, MM, YYYY)
إليك طريقة تطبيق الخصومات على اشتراكك
مرحباً،
في حال اشتراكك في إي آند من خلال عرض ترويجي أو خصمٍ ما، سيتم تطبيق هذا العرض ابتداءً من أول شهر كامل من الاشتراك، وذلك لضمان استفادتك الكاملة من المزايا المتاحة.
ويمكنك في أي وقت إدارة حسابك وباقتك والمزايا المرتبطة بها عبر تطبيق إي آند، كما يمكنك تفعيل الدفع التلقائي (Autopay) لتسهيل إدارة مدفوعاتك.

حمّل  تطبيق إي آند الآن: [$Link$]
لمزيد من المعلومات حول فاتورتك:
[$Link$]
شكرًا لاختيارك إي آند.
© 2025 إي آند. جميع الحقوق محفوظة.
تم إرسال هذا البريد الإلكتروني تلقائياً، يرجى عدم الرد عليه.

---

## Email 3

### BEFORE

Subject:
Service Suspension Notice due to Non-Payment Bill

Header:
Service Suspension due to Outstanding Payment

Body:
Dear Customer, 
We are informing you that your account $account_number$ has exceeded the "Promise to Pay" commitment deadline without receiving the payment. Due to an outstanding balance of AED $amount_due$, we have temporarily suspended outgoing calls and data services on your account.

To restore your services without further delay, please make the payment of the outstanding balance by visiting etisalat.ae/quickpay. Once your payment is processed, all services will be automatically restored. Thank you for choosing e&.

### AFTER — English

Subject:
Important: Your outgoing calls and data have been suspended

Header:
Pay now to reconnect

Body:
Hello there, 

You haven’t paid your bill for AED $amount_due$ on account $account_number$. This means you’ve now exceeded your "Promise to Pay" commitment, and your outgoing calls and data have been suspended. 

This may affect your ability to enjoy e& services in the future.

Pay now to reconnect with everything e&. 

CTA: Pay now

Thank you

The e& Team

### AFTER — Arabic

Subject:
تنبيه هام: تم إيقاف المكالمات الصادرة والبيانات مؤقتاً
Header:
ادفع الآن لاستعادة الخدمة
مرحباً،
لم يتم سداد مبلغ $amount_due$ درهم المستحق على الحساب $account_number$، ونتيجة لذلك تم تجاوز الموعد المتفق عليه للسداد، ما أدى إلى إيقاف المكالمات الصادرة وخدمة البيانات مؤقتاً.
قد يؤثر ذلك على استمرار استفادتك من خدمات إي آند مستقبلاً.
يمكنك السداد الآن لإعادة تفعيل الخدمة والاستمتاع بخدمات إي آند من جديد.
CTA:
ادفع الآن
شكراً لك،
فريق إي آند

---

## Email 4

### BEFORE

Subject:
Your e& Services Have Been Suspended

Header:
Imediate Action Needed

Body:
Dear Customer,
We are informing you that your account $account_number$ has exceeded the "Promise to Pay" commitment deadline without receiving the payment. Due to an outstanding balance of AED $amount_due$, we have temporarily suspended all services on your account.

To restore your services without further delay, please make the payment of the outstanding balance by visiting etisalat.ae/quickpay. Once your payment is processed, all services will be automatically restored. Thank you for choosing e&.

### AFTER — English

Subject:
Important: Your e& services have been suspended

Header:
Pay now

Body:
You have missed your "Promise to Pay" deadline for AED $amount_due$ on account $account_number$. All of your services are now suspended.

This may impact your credit score, and affect your ability to use e& in the future.

Pay now to reconnect. 

CTA: Pay now

Thank you

The e& Team

### AFTER — Arabic

Subject:
تنبيه هام: تم إيقاف جميع خدمات إي آند
Header:
ادفع الآن
بسبب عدم سداد مبلغ $amount_due$ درهم المستحق على الحساب $account_number$ ضمن المهلة المحددة، تم إيقاف جميع خدماتك مؤقتاً.
قد يؤثر ذلك على سجلك الائتماني وعلى الاستفادة من خدمات إي آند مستقبلاً.
يمكنك السداد الآن لإعادة تفعيل الخدمات.
CTA:
ادفع الآن
شكراً لك،
فريق إي آند

---

## Email 5

### BEFORE

Subject: Make your home smarter with the $New Neo Smart Home Plan$
Header: $5$ smart devices for just $AED 100 per month$

Dear <Customer>,

Explore our $New Neo Smart Home Plan$, the perfect add-on to your existing elife services for just AED $100$ per month.

As part of this plan, you get 5 smart devices:
1x Smart Camera or Doorbell to monitor your home from anywhere
1x Smart Lock Bundle to manage your home remotely
1x Smart Wall Switch to control your lights with ease
1x Echo Pop for voice controlling your smart home
1x IoT Hub for controlling all your smart devices
Ready to upgrade?

Visit $Link$ to make your home smarter, safer, and more connected. 
If you have any questions or need assistance, our customer service team is here for you anytime.

Thank you for choosing e&. We look forward to serving you.

### AFTER — English

Subject: 
Make home smarter and safer with the $New Neo Smart Home Plan$

Header: 
5 upgrades. AED 100/month. That’s smart.

Body:
Hello <Customer>,

Discover the $New Neo Smart Home Plan$, the smart add-on that makes your home smarter and safer – for just AED 100/month.

Keep an eye on your home from anywhere, lock doors remotely, turn on lights with a tap, and manage everything with your phone – or your voice. 

Here’s what’s included with the plan:

1x Smart Camera or Doorbell
1x Smart Lock Bundle
1x Smart Wall Switch
1x Echo Pop (voice control hub)
1x IoT Hub

Ready to upgrade?

CTA: Upgrade now [$Link$]

Have questions? Contact support – available 24/7.

Discover a world of more with e&.

### AFTER — Arabic

Subject:
بيتك أذكى وأكثر أماناً مع $New Neo Smart Home Plan$
Header:
5 ترقيات بـ100 درهم شهرياً
مرحباً <Customer>،
اكتشف $New Neo Smart Home Plan$ — إضافة ذكية ترفع مستوى الأمان والراحة في منزلك، مقابل 100 درهم شهرياً فقط.
تابع منزلك من أي مكان، تحكّم في الأبواب والإضاءة وأكثر عن بُعد، بسهولة عبر هاتفك أو بالصوت.
تشمل الباقة:
كاميرا ذكية أو جرس باب ذكي (1)
حزمة القفل الذكي (1)
مفتاح حائط ذكي (1)
جهاز Echo Pop للتحكّم الصوتي (1)
جهاز IoT Hub (1)
جاهز للترقية؟
CTA:
قم بترقية باقتك الآن [$Link$]
فريق الدعم متوفر في خدمتكم على مدار الساعة لأي استفسار.
دايماً في أكثر مع إي آند.

---

## Email 6

### BEFORE

Subject: Your e& Device Protection Plan is Now Active

Dear $Customer Name$,

Congratulations on protecting your $Device Insured$ with e& Device Protection! Your coverage starts today ($Today's Date$), giving you peace of mind against unexpected damage for the next 2 years.

Your Policy
•        Policy Number: $Policy No.$
•        A full copy of your policy document will be sent to your registered email by Protect4Less, our authorised insurance partner who manages the full claims process.

Making a Claim
If you ever need to make a claim:
•        e& Customers: Submit your claim directly via the e& UAE app, under the $section1$ section.
•        Non-e& Customers: Submit your claim at www.protect4less.com.

Claims are typically processed within 24–48 hours, and you will be notified by email at every stage. For assistance regarding your claims, please contact customercare@protect4less.com, and for any other enquiries, please contact e& customer support.

Thank you for choosing e& Device Protection.

Best regards,
The e& Team

### AFTER — English

Subject: 
Your e& device is now protected – enjoy peace of mind

Body:
Hello there,

Great news – your $Device Insured$ is now protected against accidental damage for the next two years with e& Device Protection. 

Here’s everything you need to know:

Your policy
- Policy number: $Policy No.$. 
- Start date: ($Today's Date$)
- End date: $TwoYearsFromToday:dd MMMM yyyy$ 

You’ll also get a full copy of your policy via email from Protect4Less, our authorised insurance partner.

Making a claim
- If you’re an e& customer, submit your claim in the e& app, under $section1$ 
- If you're not an e& customer, submit your claim at www.protect4less.com
- Claims are typically processed within 24–48 hours

Have questions about a claim? Email customercare@protect4less.com

Have other questions? Contact e& support – available 24/7._x000B_

Welcome to a world of more.

### AFTER — Arabic

Subject:
تم تفعيل حماية جهازك من إي آند
مرحباً،
تم تفعيل خدمة حماية الأجهزة من إي آند لجهازك $Device Insured$، لتشمل الحماية من الأضرار العرضية لمدة عامين.
معلومات التغطية:
رقم الوثيقة: $Policy No.$
تاريخ ابتداء التغطية: ($Today's Date$)
تاريخ انتهاء التغطية: $TwoYearsFromToday:dd MMMM yyyy$
كما ستصلك نسخة كاملة من وثيقة التأمين عبر البريد الإلكتروني من Protect4Less، شريك إي آند المعتمد.
في حال الحاجة إلى تقديم مطالبة:
يمكن لعملاء إي آند تقديم المطالبة عبر تطبيق إي آند، ضمن قسم $section1$
يمكن لغير عملاء إي آند التقديم عبر الموقع:
www.protect4less.com
تتم مراجعة المطالبات خلال 24–48 ساعة عادةً
للاستفسار عن المطالبات، يمكن التواصل مباشرةً مع Protect4Less عبر:
customercare@protect4less.com
ولأي استفسارات أخرى، فريق دعم إي آند متوفر في خدمتكم على مدار الساعة.
مع إي آند، دايماً في أكثر.

---

## Email 7

### BEFORE

Pay Your Bill Today
Account Number: < Acc>
DD, MM, YYYY
Don't Delay and Pay Now!
Dear Customer,
This is an important reminder that your account bill is due today. Please settle your bill today and continue enjoying your e& services.
Bill Details
Account Number: $account_number$
Amount Due: $amount_dues
Due Date: $due_Date$
Spend more time enjoying your e& services and let Autopay take care of your bill payments.
SET UP AUTOPAY
View & pay your bill easily on the e& UAE app
<Standard Footer>

### AFTER — English

Subject:
Important: Your bill is due today

Header:
Make a payment today

Body:
Hello there, 

Your bill for $amount_due$ on account $account_number$ is due today.

Pay now and continue to enjoy life on the UAE’s original mobile network. Or set up Autopay and never miss a payment.

CTA: Pay now

Thanks,

The e& Team

### AFTER — Arabic

Subject:
تنبيه هام: موعد سداد فاتورتك اليوم
Header:
سدّد اليوم لتفادي أي انقطاع
مرحباً،
نودّ تذكيرك بأن فاتورتك بقيمة $amount_due$ درهم على الحساب $account_number$ مستحقة اليوم.
يمكنك السداد الآن للاستمرار في استخدام والاستمتاع بخدمات إي آند.
ولتفادي تفويت أي دفعة مستقبلاً، يمكنك أيضًا تفعيل الدفع التلقائي (Autopay).
CTA:
ادفع الآن
شكرًا لك،
فريق إي آند

---

## Email 8

### BEFORE

Subject: Your $Parental Control $ subscription is confirmed 
HEADER: Enjoy $3 Months free_Offer$ + free installation

Dear <Customer>,

Thank you for subscribing to the $Parental Control$ Service! Your subscription has been successfully added to your eLife account $[Account Number]$. Enjoy $3 months FREE$ until $Offer-expiry date$. After the free period, standard monthly charges will apply. 

To complete your installation, please book a technician visit here: $Book_Link$.
Note: Free installation is subject to the type of router you have. 
 
To learn how $Parental Control$ can help create a safer online space for your family, visit: $Link$.

If you have any questions or need assistance, our customer service team is here for you anytime.

Thank you for choosing e&. We look forward to serving you.

### AFTER — English

Subject: 
Welcome to $Parental Control$

Header:
Keeping your family safe

Body: 
Hello there,  

Thanks for subscribing to e&’s $Parental Control$ service. We’ve now added it to your eLife account: $[Account Number]$. 

And as a new subscriber, we’re giving you the first 3 months free. Plus, free installation for selected routers. Because sometimes more is more.

Ready to book your installation?  

CTA: Book now: $Book_Link$.    

Learn more about how $Parental Control$ keeps your family safe: [$Link$] 

Welcome to a world of more.

### AFTER — Arabic

Subject:
تم تفعيل خدمة الإشراف الأبوي
Header:
أمان عائلتك يبدأ من هنا
مرحباً،
تم تفعيل خدمة الإشراف الأبوي من إي آند وإضافتها إلى حساب eLife الخاص بك
(رقم الحساب: $Account Number$).
وبمناسبة اشتراكك الجديد، يمكنك الاستمتاع بالأشهر الثلاثة الأولى مجاناً،
إلى جانب تركيب مجاني على أجهزة مختارة.
هل ترغب بتحديد موعد التركيب الآن؟
CTA:
احجز موعد التركيب: $Book_Link$
للاطلاع على تفاصيل الخدمة وكيف تساعدك على إدارة استخدام الإنترنت في المنزل:
$Link$
مع إي آند، دايماً في أكثر.

---

## Email 9

### BEFORE



### AFTER — English

Subject: 
Urgent: data and SMS roaming restrictions in Russia

Header:
What you need to know

Body:
Dear Customer,

Russia is now suspending data and SMS roaming services for 24 hours on arrival. Voice calls aren’t affected.

This is a mandatory suspension for all international users, which we weren’t informed about beforehand. 

Here’s what you need to know:

- When you first connect to a Russian network, your data and SMS will be suspended for 24 hours
- You can still make voice calls
- If you don’t use your SIM for 3 days after the suspension, Russia will apply a second 24-hour suspension 

What we recommend:

- Use Wi-Fi where possible
- Expect data and SMS outages during your stay
- Let friends and family know about the suspension before you travel
- Keep updated about restrictions in the e& app  

Have questions? We’re on hand to help 24/7. 

CTA: Contact support

Thank you,

The e& team

### AFTER — Arabic

Subject:
تنبيه عاجل: قيود على التجوال (البيانات والرسائل) في روسيا
Header:
معلومات مهمة قبل وأثناء السفر
مرحباً،
طرأت تحديثات جديدة على خدمات التجوال في روسيا، بحيث يتم إيقاف خدمات البيانات والرسائل النصية مؤقتاً لمدة 24 ساعة عند الوصول.
المكالمات الصوتية غير متأثرة وتعمل كالمعتاد.
هذا الإجراء إلزامي ويُطبق على جميع المستخدمين الدوليين.
ما الذي يجب معرفته:
عند الاتصال بشبكة روسية للمرة الأولى، سيتم إيقاف البيانات والرسائل النصية لمدة 24 ساعة
يمكنك الاستمرار في إجراء واستقبال المكالمات الصوتية
في حال عدم استخدام شريحتك لمدة 3 أيام بعد انتهاء الإيقاف، قد يتم تطبيق إيقاف إضافي لمدة 24 ساعة
نوصي بما يلي:
استخدام شبكات Wi-Fi كلما أمكن
توقع انقطاع مؤقت في خدمات البيانات والرسائل خلال فترة إقامتك
إبلاغ العائلة أو الأصدقاء بهذه القيود قبل السفر
متابعة آخر التحديثات عبر تطبيق إي آند
فريق الدعم متوفر في خدمتكم على مدار الساعة لأي استفسار.
CTA:
تواصل مع الدعم
شكراً لك،
فريق إي آند

---
