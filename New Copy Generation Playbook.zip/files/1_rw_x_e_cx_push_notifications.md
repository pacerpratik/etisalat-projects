# e& CX Push Notifications — Before / After

**Description:** Description: Approved before/after rewritten push notification copy examples for e& B2C communications. Includes Title, Short Description, Long Description, and CTA fields in English and Arabic.

---

## Push Notification 1

### BEFORE

Title: Your plan is active. 
Short Description: Welcome to e&. A free welcome gift is ready for $ACCOUNT_NUMBER$.
Long Description: Get started on your new plan with something special. Choose a welcome gift like data, minutes, Careem Plus & more. You have <X> days to claim.  
CTA- Claim now

### AFTER — English

Title: 
Welcome to a world of more

Short Description: 
Here’s your free welcome gift from the UAE’s original mobile network.

Long Description: 
Choose from data to minutes and more. Claim your free gift within <X> days – it’s our way of saying thank you, and welcome to the UAE's original mobile network.

CTA: Claim now

### AFTER — Arabic

Title:
دايماً في أكثر مع إي آند
Short Description:
إليك هدية ترحيبية من أول شبكة اتصالات في الإمارات
Long Description:
اختر هديتك الخاصة، واستفد من البيانات والدقائق المجانية وأكثر.
احصل عليها خلال <X> أيام — مرحباً بك وشكراً لانضمامك لأول شبكة اتصالات في الإمارات.
CTA:
اختر هديتك

---

## Push Notification 2

### BEFORE

Title:  Claim your gift.  
Short Description: Hurry – You have <X> days left to claim your welcome gift for account $ACCOUNT_NUMBER$.
Long Description: Enjoy a free welcome gift. Choose from options like data, minutes or Careem Plus and enjoy uninterrupted services with e&. Don’t miss out – just <X> days left to claim. 
CTA – Claim now.

### AFTER — English

Title: 
Your free gift is waiting...

Short Description: 
Want to talk more, watch more, or eat more? Claim today before it expires.

Long Description: 
Choose from data to minutes and more. Claim your free gift within <X> days – it’s our way of saying thank you, and welcome to the UAE's original mobile network.

CTA: Claim now

### AFTER — Arabic

Title:
هديتك بانتظارك..
Short Description:
مكالمات أكثر، مشاهدة أكثر، وحتى أكل أكثر — احصل عليها اليوم قبل انتهاء صلاحيتها.
Long Description:
اختر هديتك الخاصة، واستفد من البيانات والدقائق المجانية وأكثر.
احصل عليها خلال <X> أيام — مرحباً بك وشكراً لانضمامك لأول شبكة اتصالات في الإمارات.
CTA:
اختر هديتك

---

## Push Notification 3

### BEFORE

Title: Your gift expires today.
Short Description: Your plan includes a free welcome gift – act now to make the most of your plan. 
Long Description: Today is your final chance to enjoy something extra with your new plan. Redeem your gift before it expires tonight and continue experiencing the best of e&. 
CTA – Claim now.

### AFTER — English

Title: 
Time's almost up...

Short Description: 
Hurry – your free welcome gift expires at midnight.

Long Description: 
Your gift expires at midnight – don’t miss out on a world of more. Choose from data, minutes, or even Careem Plus. _x000B_

CTA: Claim now

### AFTER — Arabic

Title:
سارع! تبقى القليل..
Short Description:
ستنتهي صلاحية هديتك الترحيبية عند منتصف الليل.
Long Description:
ستنتهي صلاحية هديتك عند منتصف الليل. اختر من بين بيانات ودقائق مجانية وحتى اشتراك في Careem Plus. مع إي آند، دايماً في أكثر.
CTA:
اختر هديتك

---

## Push Notification 4

### BEFORE

Title: Add-on charges due soon
Short Description: Friendly reminder that your add-on fees will be deducted soon. View and manage your add-ons and keep enjoying the services.
Long Description: Your add-on fees will be deducted from your account shortly. For uninterrupted service click below to manage your add-ons.
CTA: Manage Add-ons

### AFTER — English

Title: 
Add-on payment coming up 

Short description: 
Your add-on fees will be charged on <due date>. Manage your add-ons now in the e& app.

Long description:  
Not enough credit in your account? Recharge in a few clicks in the e& app.

CTA: Visit the app

### AFTER — Arabic

Title:
اقترب موعد خصم الباقة الإضافية
Short Description:
سيتم خصم رسوم الباقة الإضافية بتاريخ <due date>. يمكنك إدارتها الآن عبر تطبيق إي آند. 
Long Description:
رصيدك غير كافِ؟
يمكنك إعادة تعبئة الرصيد بخطوات بسيطة عبر تطبيق إي آند
CTA:
افتح التطبيق

---

## Push Notification 5

### BEFORE

Title: Manage Auto-Renew Add-Ons
Short Description: Friendly reminder, you have an auto renewing Add-on, take a moment to review your add-ons at your convenience.
Long Description: Your $add-on_name$ will be auto-renewal soon. To view and manage your add-ons for the upcoming month click below.
CTA: Manage Add-ons

### AFTER — English

Title: 
Your add-on will auto-renew on <date>

Short Description: 
There's nothing for you to do – just keep enjoying $add-on_name$. Manage your add-ons in the e& app.

### AFTER — Arabic

Title:
سيتم تجديد الباقة الإضافية تلقائياً بتاريخ <date>
Short Description:
لا يلزمك أي إجراء الآن سوى الاستمتاع بـ$add-on_name$، ويمكنك إدارة الباقات الإضافية عبر تطبيق إي آند.

---

## Push Notification 6

### BEFORE



### AFTER — English

Title
We’ve found a technical issue with your service.

Short description
Don’t worry – we’ll send a technician to fix it for free. Book a time that works for you: &LINK&

### AFTER — Arabic

Title:
تم رصد خلل تقني في خدمتك
Short Description:
لا داعي للقلق، سنتولى عملية إصلاح الخلل دون أي تكلفة. كل ما عليك فعله هو أن تحدّد الموعد المناسب لك: &LINK&

---
