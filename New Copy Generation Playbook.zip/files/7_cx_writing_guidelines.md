# CX writing guidelines

---

## What is this document?

These are our CX writing guidelines.
Their aim is twofold. First, to help you write clear, effective, and consistent CX copy that reflects our masterbrand voice. Second, to help e& build lasting trust with customers.

| What this document **is**: | What this document **isn't**: |
|---|---|
| • A detailed guide on how to apply our masterbrand voice to CX writing, across emails, SMS, push notifications, and our app and website | • A replacement for our masterbrand voice |
| • Practical advice | • A new and separate voice |

---

## How to use this document

These guidelines are the source of truth for all CX writing. And you should use them in three ways: to write, edit, and review.

Importantly, this includes your own writing and your colleagues' writing.

These guidelines are for you as a writer, for your team, and for e& as a brand.

---

## Contents

- CX writing persona — 6
- CX writing principles — 9
  - Principles in action — 15
- Adapting our principles — 19
  - Channels — 20
  - Audiences — 30
  - Businesses — 47
- Writing for journeys — 54
- Writing for moments — 60
- Writing for crises — 66
  - Handling difficult emotions — 67
  - Handling sensitive subjects — 73
- Compliant communications — 76
- Writing checklist — 79
- Writing with AI — 82
  - Writing new copy — 87
  - Reviewing and rating existing copy — 89
  - Evaluating AI copy — 91
- CX glossary — 94

---

## CX writing persona

*Confidential. For internal and partner use only. Images, copy, and application examples throughout these pages are for concept demonstration and guidance purposes only. No usage rights or buyouts have been secured for imagery and illustrations. Images and illustrations rights must be acquired on a case-by-case basis.*

---

### CX writing persona

A persona is a character and a mindset you should adopt when writing. A role for you to embody. Everything you write should feel true to this persona.

1. For e&\*, it helps create a consistent voice across channels and touchpoints. This builds brand familiarity and customer trust.
2. For you, it's a tool, and an easy way to test copy.

\*We always refer to ourselves as e&, never Etisalat.

---

### Our CX writing persona is: The Inspiring Guide

**Communicates with clarity.**

**Gives directions with certainty.**

**Helps everyone reach their goal, no matter who they are or how they're feeling.**

**Inspires people to achieve, do, and experience more.**

**Always anticipates the next step of their journey.**

**How to use this persona:**

When you write: imagine you're an inspiring guide. What would they say?

When you edit: ask yourself if an inspiring guide would say that. If not, rework your message.

---

## CX writing principles

*Confidential. For internal and partner use only. Images, copy, and application examples throughout these pages are for concept demonstration and guidance purposes only. No usage rights or buyouts have been secured for imagery and illustrations. Images and illustrations rights must be acquired on a case-by-case basis.*

---

### CX writing principles

These are our three core aims when writing for CX. They help us write in our voice, create inspiring experiences, build trust, and guide customers forward. Our principles are:

1. **Know their journey**
2. **Lead with clarity**
3. **Inspire to do more**

---

### 1. Know their journey

Every CX message is part of a journey. And every customer is different. We won't know everything about them\*, but we need to use what we do know to direct and edit our writing. Ask yourself these questions:

\*See page 44 for more on writing without audience info.

**1. Who am I talking to?**

Are they Emirati, Blue Collar, or part of another audience? A new customer, or a life-long one? Write for the individual.

- For Emirati: Dear Zayed, you've used 90% of your monthly data.
- For Youth: Heads up Zayed – you're down to 10% of your data.

للإماراتي: عزيزي زايد، لقد استخدمت 90% من بياناتك الشهرية.  
للشباب: تنبّه زايد — بقي لك 10% من بياناتك.

**2. What do they already know?**

Look at their last step or action. What have they just seen, read, or clicked on? Write for that journey.

- Creating an account: Thanks for choosing e&. See you online.
- Closing an account: Thanks for choosing e&. We hope to see you again.

عند إنشاء الحساب: شكراً لاختياركم e&. نتمنى الاستمتاع بك.  
عند إغلاق الحساب: شكراً لاختياركم e&. نتطلع لرؤيتك مرة أخرى.

**3. What do they need to know?**

Only include the information they need in that moment. Whether that's to pay a bill or learn about a prepaid plan.

- ✅ The right amount: Your bill for 450 is due on July 5.
- ❌ Too much: Your bill for 450 is due on July 5. Account holder: Aisha Al Shamsi Account created: 21 January, 2020.

المناسبة: فاتورتك بمبلغ 450 تستحق في 5 يوليو.  
غير المناسبة: فاتورتك بمبلغ 450 تستحق في 5 يوليو. صاحب الحساب: عائشة الشامسي. تاريخ إنشاء الحساب: 21 يناري 2020.

---

### 2. Lead with clarity

CX journeys are complicated. So we always strive for clarity, to help users know what they need to do at every step. Leading isn't pushy though, or aggressive. It's confident. Always ask:

**1. Can I make the sentence simpler?**

Short sentences beat long. Swap complex words for simple ones. This doesn't just create clarity for our global audience, it also shows we're confident enough to say more with less.

- ✅ Switch at your own speed / تسابق بسرعتك
- ❌ Friendly towards gradual migration / الانتقال التدريجي الذي يراعي رغباتك الأخرى

- ✅ Extra info / تعلمك أكثر
- ❌ Additional information / تعلمك مفلومات إضافية أخرى

**2. Will they understand the details?**

Some technical terms are necessary, like "authenticate". But watch out for unnecessary jargon, and explain any terms you can't avoid.

- First Time: B1G1 (Buy-1-get-1) / عرض 1+1 (واحد واحد أنا وأنا جماني)
- Second Time: B1G1 / عرض 1+1

- ✅ Instant estimate / تقدير فوري
- ❌ On-the-spot device evaluation / تقييم الجهاز في نفس اللحظة

**3. What do I want them to do next?**

Focus on one action. Be specific. Use strong verbs to make it exciting. Keep CTAs short: 2–5 words.

- ✅ Make it specific: Discover premium / اكتشف مميزي
- ❌ Learn more / اعرف المزيد

- ✅ Make it short: Discover premium / اكتشف مميزي
- ❌ Discover exclusive premium benefits / اكتشف مزايا مميزي الحصرية

---

### 3. Inspire to do more

We want users to do more than just complete a task, or create an account. We want them to feel energised, enriched, and inspired. Or sometimes just reassured. Our voice makes that happen.

**1. What do I want them to feel?**

Reassured when there's a problem. Inspired when they visit our site. Excited when they sign up. Use language that supports that feeling.

- ✅ With feeling: Face ID is now on. More control, more security.
- ❌ Too functional: Face ID enabled.

دار متشعر: صبّت الوجه هاللحظة. أمن أكثر وتحكّم أكثر.  
دار جاف: صبّت الوجه هاللحظة.

**2. How do I bring small moments to life?**

CX is full of small moments, like logging in or adding data. Make them more than tasks with vivid language and a touch of wit.

- ✅ Bring to life: Add data. Stay streaming. / أضف بيانات. واستمتع بالمشاهدة.
- ❌ Don't let the stream dry up! Add more data now. / لا تدع البث يتوقف! أضف المزيد من البيانات الآن لتستمتع بالمشاهدة.
- ❌ Add data / أضف بيانات

**3. How do I make big moments feel even bigger?**

Creating an account, buying an iPhone, or even a smart TV. For these moments – be bold. Use aspirational language, and speak to the future.

- ✅ Create anticipation: Your new phone is almost online… / أكثر من هاه في عالمٍ لأكثر، هاك جديدك تقوتنا… ولك
- ❌ Your new phone is nearly ready / دق جديدك أصبح جاهز تقريباً

- ✅ Show the possibilities: Welcome to a world of more / اهلاً في عالم أكثر
- ❌ You've now joined e& / دق انضممت الآن لمتمنه

---

### Summary — CX writing principles

| Know their journey | Lead with clarity | Inspire to do more |
|---|---|---|
| Every CX message is part of a journey. And every customer is different. We won't know everything about both, but we need to use what we do know to guide our writing and their journey. | CX journeys are complicated. So we always strive for clarity, to help users know what they need to do at every step. Leading isn't pushy though, or aggressive. It's confident. | We want users to do more than just complete a task, or create an account. We want them to feel energised, enriched, and inspired. Or sometimes just reassured. Our voice makes this happen. |
| This creates an experience that feels effortless and relatable, and inspires trust. | This creates clarity in our brand, and inspires certainty for our customers. | This helps us write with personality, and deliver on our purpose. |

---

## CX writing principles in action

---

### Principles in action — Example

**Original copy:**

> Dear customer, your subscription to PLAN_NAME (monthly rental 100 + 10 VAT) has been completed successfully. Your postpaid plan will be auto-renewed on a monthly basis and the monthly rental for the relevant subscribed plan shall be applicable. To check countries available for in-bundle international minutes of your plan PLAN_NAME, please click on https://etisalat.ae/flexcalllist. To view the latest plan details, please visit www.etisalat.ae/fl. Your plan also comes with exciting benefits of Smiles Unlimited Buy 1 Get 1 offer worth 240/year and FREE GoChat stickers worth 50/month. To redeem and learn how to start using your benefits, visit etisalat.ae/promotions. Exit charges apply in the first 12 months as per applicable rules. To manage your subscription, log on to My e& UAE app.

**Applying the principles:**

- **What do I want them to feel?** Relaxed. So let's drop formal language like "Dear" and "applicable".
- **Can I make it simpler?** The structure is dense and hard to digest. So let's break it up.
- **How can I bring this small moment to life?** It needs a touch of wit, so it doesn't feel purely transactional.
- **What do they need to know?** They don't need every plan detail, especially as they will have just read about it online.
- **What do I want them to do next?** We want them to learn about the benefits. So let's add a clear CTA.

**Before (Arabic):**

مرحباً بك، لقد تمّت عملية الاشتراك في خطة [PLAN_NAME] بنجاح (اشتراك شهري بسعر 100 درهم + 10 درهم ضريبة القيمة المضافة). سيتم تجديد خطة الاسم لاحقاً بشكل تلقائي كل شهر، ويتم احتساب المبلغ الشهري المناسب للاشتراك. لمعرفة الدول المتاحة لدقائق الاتصال الدولي المدمج في خطتك [PLAN_NAME]، يرجى الضغط على الرابط: https://etisalat.ae/flexcalllist. لمعرفة تفاصيل الخطة الأخيرة، يرجى زيارة: www.etisalat.ae/fl. تشتمل خطتك أيضاً على مميزات رائعة، تشمل عرض اشتراك Smiles (واحد واحد ومميزات ومنافع للقيمة المضافة)، بقيمة 240 درهماً سنوياً، وملصقات GoChat مجانية بقيمة 50 درهماً شهرياً. للاستفادة منها ومعرفة كيفية الاستمتاع بمزاياك، يرجى زيارة: etisalat.ae/promotions. قد تُطبَّق رسوم خروج لأول 12 شهراً وفقاً للقواعد المعمول بها. لإدارة خطتك، يرجى تسجيل الدخول إلى تطبيق My Etisalat UAE.

**After (English):**

> Hi [name],
> 
> You're now subscribed to PLAN_NAME (set at 100 + 10 VAT monthly). We'll automatically renew it and charge you each month, so you can be hands-off from here. If you do want to update anything, just use your e& UAE app.
> 
> Your plan also comes with:
> - Our Smiles Unlimited Buy 1 Get 1 offer (worth 240/year)
> - Free GoChat stickers (worth 50/month)
> 
> Want to redeem them? Head to etisalat.ae/promotions.

**After (Arabic):**

أهلاً [الاسم]،

أنت الآن في خطة [PLAN_NAME] بسعر اشتراك 100 + 10 درهم (القيمة المضافة) شهرياً. سيتم احتساب المبلغ وتجديد الاشتراك تلقائياً بدون تدخل منك. إذا رغبت في تعديل أي شيء، يمكنك استخدام تطبيق e& UAE.

تشتمل خطتك أيضاً على:
- عرض اشتراك Smiles Unlimited بالقيمة المضافة (1 لصحاك ومنافع جماني) بقيمة 240 درهماً سنوياً
- ملصقات GoChat مجانية بقيمة 50 درهماً شهرياً

هل تبغت في الاستفادة من مزاياك؟ توجه إلى: etisalat.ae/promotions

---

## Adapting our principles

*Confidential. For internal and partner use only.*

---

## Writing for channels

### Email

An email should feel like a direct, personal conversation. And even though you have more space than an SMS, you should always respect our customers' time, and inbox.

**Things to keep in mind**

Do this more…
- Write as if you're speaking
- Address customers directly, with "you" and "your"
- Personalise, if possible

Don't worry about…
- Every detail, only the information they need to know in that moment
- Prioritising creativity – clarity comes first

And remember…
- One action per CTA

**Before:**

> Dear customer,
> Kindly be reminded that your bill due date is nearing.
> Account Number: $account_number$
> Amount Due: $amount_dues
> Due Date: $due_Date$
> CTA: Pay now

**After (English):**

> Hello [First name],
> Just a heads up: your bill for 200 is due on [DATE].
> Pay now or set up Autopay, and have more time to enjoy more of life on the UAE's original mobile network.
> CTA: Pay now

**After (Arabic):**

أهلاً، [الاسم الأول]،

تذكير: فاتورتك بمبلغ 200 درهم تستحق في {التاريخ}.

ادفع الآن أو فعّل الدفع التلقائي والاستمتع بخدمات e& الإماراتية لتتمتع بالمزيد في حياتك. المبلغ المستحق: $amount_dues. تاريخ الاستحقاق: $due_Date$

انضم الآن لعيش تجربة e& الإماراتية

CTA: ادفع الآن

---

### SMS

Longer messages are less engaging, and cost more. So we aim for fewer than 320 characters, prioritise clarity, and enrich small moments to make them feel bigger.

**Things to keep in mind**

Do this more:
- Keep sentences short
- Lead with value for the customer
- Use snappy language to create pace (or urgency, if needed)

Don't worry about…
- Every detail – focus on the essentials
- Full sentences, especially if you're short on space

And remember…
- Your message can span multiple SMSs, but ensure each SMS makes sense on its own
- Dynamic content like plan names will affect overall character count

**Before:**

> Dear &Customer, your non-stop mobile data is almost full. You have consumed 90% of your monthly local data. To keep enjoying e& services, you can recharge now or upgrade your plan via e& app.

**After (English):**

> [Name], you're down> to 10% of your monthly data. Need more? Recharge in the app.

**Before (Arabic):**

دق تنبّه أي، أنا زايد — لقد استخدمت % 90 من بياناتك الشهرية المحلية. لمعرفة رصيدك المتبقي أو لاستخدام بيانات إضافية، اضغط الرقم 101# والاطلاع على عروض بيانات إضافة متنوعة وجذابة.

**After (Arabic):**

أي زايد، دق استخدمت 90% من بياناتك الشهرية. تحتاج أكثر؟ أعد الشحن من القيبطة.

---

### Website

This is where our voice is the most inspiring and confident. We don't need to include every detail everywhere. Instead we focus on value and vision.

**Things to keep in mind**

Do this more…
- Make an impact
- Dial up the inspiration
- Create a narrative

Don't worry about…
- Long introductions. We should always be concise.
- Avoiding repetition completely – it builds familiarity across our website

And remember…
- People don't read everything. Make an impact fast, and frontload important information

**Before:** Device Trade-in — Trade in your old device and get e& money credit or Smiles points to use towards bill payments, recharges, new devices, plans, and more!

**After:** Get gold from old — Trade in your old tech, and get credit towards your dream device.

*Know their journey: Leave finer details, like terms, for lower-level pages.*
*Lead with clarity: Especially in body copy to support creative headlines.*

---

**Before:** Up to 50% off for 6 months

**After:** Half the price. Half a year.

*Inspire to do more: Use touches like repetition to make normal information feel exciting.*

---

**Before (Arabic):**

استبدل قديمها، واستبدل بشراء جديد للقيمة المضافة ومنافع إضافية، واحتساب لصحا ومنافع e& money أو Smiles، خصم في الفواتير، الشحن، الأجهزة، الأجهزة والخطط، والمزيد!

**After (Arabic):**

أحصل على ذهب من قديم — استبدل تقنيتك القديمة، واحصل على رصيد نحو... المزيد.

---

**Before (Arabic):** حتى 50% لمدة 6 أشهر

**After (Arabic):** نصف السعر لنصف سنة.

---

### App (including notifications)

Apps and user journeys are complicated. Our voice has to show customers we're here to support them – whatever their goal.

**Character limits:**
- Title: 25 characters
- Short description: 90 characters
- Long description: 250 characters
- CTA: 15 characters

**Do this more…**
- Lead with clarity

**Don't worry about…**
- Being funny or overly creative

**And remember…**
- Clear writing should still feel human and empathetic
- Test your writing with teammates. Walk them through the journey.

**Before:**

> Moving soon? Bring your e& Home Services account with you, and we'll give you an 200 Smiles voucher, absolutely free.
> CTA: Home Move and get 200 Smiles voucher FREE.

**After:**

> New home. No hassle. Move!
> Relocating soon? Move your e& Home Services to your new home with our Home Move and get 200 Smiles voucher FREE.
> CTA: Move!

*Know their journey: At this moment, they don't need to know it's called Home Move.*
*Lead with clarity: Use concrete words over abstract (eg "account" not "service"). Use simple words over complex (eg "moving" not "relocating").*
*Inspire to do more: Find tiny moments to inspire, but only if there's space. Don't rely on exclamation marks.*

**Before (Arabic):**

تطخط لأبيً قريباً؟ لك معنا تامل e& UAE الجديد لتنزيل تطبيق المنزل الجديد، ويستحقوا لك 200 Smiles نقاط مجاناً.

**After (Arabic):**

منزل جديد. لا مشاكل. انتقل!  
تخط لأبيً قريباً؟ انتقل بتامل e& UAE الجديد إلى المنزل الجديد بالاعتماد على Home Move والاستمتاع بـ 200 Smiles نقاط مجاناً.

---

## Writing for audiences

### Overview

We have seven core audiences: Emirati, White Collar, Single Professionals, Blue Collar, Youth, Visitors, and Business. Each is unique in character, interests, and needs.

While the core DNA of our voice stays the same, our tone must adapt to the audience. So they feel heard, respected, and welcome.

If you don't know who you're writing to, see page 44.

---

### Emirati

| Do | Don't |
|---|---|
| Mention e&'s rich heritage in the UAE | Use slang, overly casual language, or emojis |
| Use respectful language that acknowledges experience and status | Be abrupt, especially with CTAs (eg not Get for FREE now) |
| Explain recommendations, decisions, and actions | Try to be funny. Avoid sarcasm and irony. |
| Focus on personalised service, family, progress, and trust | |
| Say "Dear [name]" if we know their name, and "Hello there" if we don't | |
| Use Arabic sign-offs. "Shukran" if space is limited, or "Shukran wa taqdeeran" otherwise. | |

**Main service models:** Prepaid, Postpaid

When writing to Emirati, we're more refined and respectful.

**Before:**

Subject: Feedback request for your $Smart Home [Plan or Add-on]$  
Preheader: Help us improve with your input

> Dear \<Customer\>,
> We'd love to hear what you think about your $Smart Home [Plan or Add-on]$ service. At e&, we are committed to providing you with the best possible experience.
> It will only take 2-3 minutes to share your thoughts through this survey: $link$
> Your feedback will help us improve and serve you better.
> Thank you for choosing e&. We truly value your input.

**After (English):**

Subject: Your opinion matters  
Preheader: Help us improve Smart Home

> Dear Ahmed,
> We're always looking to improve our service. And as a trusted customer, we'd like to hear about your experience with Smart Home.
> You can share your thoughts via the survey below, which will only take a few minutes to complete.
> CTA: Start survey
> Thanks for helping build e&, the UAE's original mobile network.
> Shukran wa taqdeeran.

**Before (Arabic):**

انضم إلى اهتمامنا: دق جديد يا أنزيزع — لقد أبدى اهتمامك في خدمة Smart Home [الخطة أو الإضافية] التي تلا استخدامنا على أساس صحيح وعروضاً جيدة، — نحن في e& نلتزم بتقديم الأجود من خدماتنا لصدقه لك.

**After (Arabic):**

موضوع: رأيكم يهمنا  
دعنا نعرف رأيك في Smart Home

أنزيزع [الاسم الأول]، نسعى دائماً لتحسين خدماتنا. وأنت كعميل موثوق، نودّ سماع رأيك في Smart Home. يمكنك مشاركة أفكارك عبر الاستبيان أدناه، والذي لن يستغرق سوى بضع دقائق لإكماله.

CTA: ابدأ الاستبيان

شكراً لمساعدتك في بنائنا لـ e& الإماراتية، شبكة الجوال الأصيلة في الإمارات.

شكراً وتقديراً.

---

### White Collar

Our international audience. White Collar typically have families, and are English-speaking, time-poor, and focused on their professional lives.

| Do | Don't |
|---|---|
| Be precise, direct, and concise | Use hyperlocal references or regional idioms |
| Focus on productivity, value, and efficiency | Assume they have lived in the UAE for a long time |
| Use helpful structures (eg bullet points) | |
| Write inclusively for a multicultural audience | |
| Lead with the most important information | |

**Main service models:** Prepaid, Postpaid

When writing to White Collar, we're more professional and efficient.

**Before:**

> Title: Data Usage Update  
> Short Description: You have consumed 80% of your 8GB roaming data.  
> Long Description: You have consumed 80% of your 8GB roaming data allocated under Freedom Plan 275 Flexi. To check and manage your data usage, please click here.  
> CTA: Check Now

**After (English):**

> Title: You've used 80% of your roaming data  
> Short Description: Recharge now or manage your plan in the app.  
> CTA: Recharge now

*Lead with the most important information. Not every notification needs a long description.*

**Before (Arabic):**

عنوان (Title): استخدمت 80% من البيانات  
وصف مختصر (Short Description): ادفع الآن لتستبع الاشتراك.  
لقد استهلك 80% من البيانات المخصصة للتجوال (Long Description-) لك ...الشبكة الطبيعية 8 تيابايتس كل من خطة Freedom Plan 275 Flexi، اضغط لتدير وتبقى.  
ادفع الآن: CTA

وصف طويل: لقد استهلكت 80% من بيانات التجوال البالغة 8 تيابايتس من خطة Freedom 275 Flexi. إدارة وجدقيد. طبيعياً White collar. رابع حتما الإدارة الاستخدامية.

الآن CTA: اشحن الآن.

---

### Single Professionals

International service workers (eg cashiers, waiters) who typically send money abroad to family. Often living in shared accommodation. Look for value, flexibility, and convenience.

| Do | Don't |
|---|---|
| Focus on flexibility and digital convenience | Be overly formal or corporate |
| Connect products and services to real life | Be pushy or salesy |
| Highlight speed and ease (eg "Tap to upgrade") | Use hyperlocal references or regional idioms |
| Write inclusively for an international audience | Make assumptions about lifestyle, like home ownership |
| | Assume they have lived in the UAE for a long time |

**Main service models:** Prepaid only

When writing to Single Professionals, we're more enthusiastic and conversational.

**Before:** Enjoy the convenience of an eSIM instantly and experience connectivity like never before.

**After:** Connect to friends, family, and life in a few clicks with an eSIM.

*Highlight speed and ease. Focus on digital convenience.*

**Before (Arabic):**

استمتع بتجربة eSIM فوراً واختصل بالأصدقاء والعائلة وابدأ تجربة اتصالية لم تعيشها من قبل.

**After (Arabic):**

تصل إلى أصدقائك وعائلتك وحياتك بزر بسيط بـ eSIM.

---

### Blue Collar

Multicultural yet rarely from the UAE, and often work in construction or household trades. They care about price, reliability, and international features.

| Do | Don't |
|---|---|
| Use simple English | Use vague or difficult language |
| Focus on price, savings, and ease of use | Use metaphors or idioms |
| Highlight our international reach | Emphasise luxury or exclusivity |
| Repeat key messages over multiple messages | Assume they have lived in the UAE for a long time |
| Lead with the most important information | |

**Main service models:** Prepaid only

When writing to Blue Collar, we're more helpful and direct.

**Before:**

> Exclusive discount alert! Get Freedom Plan 275 Flexi for just 200/month during our limited-time sale. Shop now from the e& UAE App or our website and pay in easy installments with SmartPay offers or Tabby. Limited stock, buy now.

**After (English):**

> Limited-time sale: Get Freedom Plan 275 Flexi for just 200/month.
> 20GB, 100 Wi-Fi hours, Roam like Home, International reach, and much more.
> Get it today in the e& app.

*Focus on value. A clear next step.*

**Before (Arabic):**

تنبيه! حصيك مميزة لصحا على Freedom Plan 275 Flexi بمبلغ 200 درهم فقط شهرياً. الاستبيان متاح منك والاستمتاع الكلي بالزيادة والتدفع بتقسيط لاحقاً أو يسير مع SmartPay أو Tabby.

**After (Arabic):**

بيع لصحا على Freedom Plan 275 Flexi بمبلغ 200 درهم شهرياً.  
20GB، 100 ساعة Wi-Fi، تجوّل كأنك في كنك، المزيد.  
احصل عليه اليوم في تطبيق e& UAE.

---

### Youth

Digitally savvy, fluent in slang and emojis, and tuned in to both pop culture and global issues. Youth have a keen sense for when a brand is being authentic – or not.

| Do | Don't |
|---|---|
| Use emojis sparingly across SMS and app (but never more than one at a time) | Overuse lingo or cultural references – it will feel inauthentic |
| Keep your tone light, informal, and energetic | Use formal greetings and sign-offs |
| Say less, not more | Reference cultural moments from more than two years ago |
| Carefully reference culture and modern life | Lean on lazy gen-z stereotypes, like 'chilling' or 'vibing' |
| Always double-check references | Let playfulness obscure the point you're making |
| | Assume all Youth are teenagers. Anyone below 30 is part of this audience. |

**Main service models:** Prepaid, Postpaid

When writing to Youth, we're more energetic and playful.

**Before:**

> Dear customer, you have consumed 90% of your plan's monthly local data. To know your remaining allowances or to add additional data, check our wide variety of local data packers and attractive offers by dialing *101#.

**After (English):**

> Heads up, Ahmed: you've used 90% of your monthly data.
> Need more? Recharge in the app. Or check out our data deals – *101# is the number.

*More energy. Make it playful. Find fun phrases.*

**Before (Arabic):**

تنبّه أي، أنت دق استخدمت % 90 من بياناتك الشهرية المحلية. تحتاج مساعدة بالتشويق أو إضافة بيانات إضافية؟ اضغط *101# للاطلاع على عروض البيانات والجاذبية.

**After (Arabic):**

أي زايد، دق استخدمت 90% من بياناتك الشهرية. تحتاج أكثر؟ اعد الشحن من القيطة أو *101# للاطلاع على عروض البيانات.

---

### Visitors

International tourists, business people, or expats who have recently moved. Connectivity, ease of setup, and short-term perks are important.

| Do | Don't |
|---|---|
| Be welcoming – you may be one of their first interactions in the UAE | Use hyperlocal references or regional idioms |
| Encourage and inspire to make the most of the UAE | Assume they have been in the UAE for a long time |
| Use simple English | Focus too much on long-term benefits, like annual savings or complex bundles |
| Offer helpful tips | |
| Highlight ease, speed, and connectivity | |
| Position e& as their inspiring guide to the UAE | |
| Focus more on short-term benefits | |

**Main service models:** Prepaid, Visitor line

When writing to Visitors, we're more welcoming and reassuring.

**Before:**

> Welcome to the UAE. Stay connected with your loved ones with ease. Dial *177# to get a 500MB mobile internet data roaming pack for just 35 per day. To view other roaming packages with voice options as well, and to check standard roaming rates and more information, dial *177# or order through e& UAE app (Consumer) or e& UAE Business app (Business). We wish you a great stay.

**After (English):**

> Marhaba ("Hello"), and welcome to the UAE.
> Dial *177# for 500MB (35/day) and start exploring. Then download the e& UAE app for more packs, perks, and support for your stay.

*Helpful, clear and warming. Ease and speed. Be reassuring. Focused on the short-term.*

**Before (Arabic):**

أهلاً، مَقِبل في الإمارات! اتصل بالرقم *177 للحصول على حزمة 500MB بقيمة 35 درهم يومياً. ثم حمّل تطبيق e& UAE لمزيد من الباقات والاستفادة والدعم خلال إقامتك. للاطلاع على الباقات الأخرى وأسعار التجوال وأكثر، اتصل *177# أو اطلب من خلال تطبيق e& UAE.

**After (Arabic):**

أهلاً بك! مَقِبل في الإمارات.  
اتصل بـ *177# للحصول على 500MB بقيمة 35 درهم يومياً وابدأ الاستكشاف. ثم حمّل تطبيق e& UAE للمزيد من الباقات والمزايا ودعم إقامتك.

---

### Writing when you don't know your audience

Often, we won't know who we're writing to. If you're in this situation, follow The Inspiring Guide and the advice below.

If you don't know the audience, our other writing principles still apply. So still lead with clarity, and always look for moments to inspire.

1. Know their journey
2. Lead with clarity
3. Inspire to do more

| Do this: | In writing: |
|---|---|
| Be friendly and polite, but not overly formal | "Hello" not "Dear" |
| Avoid language that only appeals to one group | "Buy now" not "Grab now" (this would only appeal to Youth) |
| Explain technical terms | "Smiles, your everyday rewards app" |
| Focus on broad ideas and benefits | "Stay connected with friends and family" not "Stay connected with your kids" |
| Avoid idioms and regional references | "Exclusive deals" not "Sweet deals" |
| | "This summer" not "This Dubai summer" |

**Arabic version:**

| الأسلوب: | في الكتابة: |
|---|---|
| مهذّب وودود بدون إفراط | "مرحباً" وليس "أهلاً [اسم]" |
| تجنّب لغة تناسب فئة واحدة | "اشتري الآن" وليس "هلّع الآن" — هذه الأخيرة تناسب الشباب فقط |
| اشرح المصطلحات التقنية | "تطبيق Smiles كافئك اليومي" |
| ركّز على الأفكار والفوائد الشاملة | "ابقَ على تواصل مع الأصدقاء والعائلة" وليس "ابقَ على تواصل مع أطفالك" |
| تجنّب التعابير الاصطلاحية والمراجع الإقليمية | "عروض حصرية" وليس "عروض جديدة" |
| | "هذا الصيف" وليس "هذا صيف دبي" |

---

## Writing for businesses

Lots of different businesses use e&, from corner shops and small consultancies to large law firms, mature enterprises, and even government bodies.

When we write for businesses, we dial up three ideas from our brand personality:

### Respect
Be more polite and professional, and acknowledge hierarchies.

### Relationships
Talk about partnerships, support, and long-term goals.

### Trust
Emphasise reliability, security, and value.

**B2C vs B2B example:**

| B2C | B2B |
|---|---|
| Hello \<Customer\>, | Dear \<Customer\>, |
| Your Home Wireless is all set up. You can start using it straight away, and your contract is set for 24 months. Home just got a little bit sweeter. | Your Business Internet is online, and your contract is 24 months. Enjoy ultra-fast internet that scales, plus 24/7 support from the UAE's original broadband network. |

*B2B: A more respectful greeting ("Dear" not "Hello"). Less casual language ("is online" not "all set up"). Focused on long-term value. Focused on relationships. Language that builds trust.*

**Arabic B2B vs B2C:**

| B2C (مرحباً) | B2B (انزيزع) |
|---|---|
| خدمة إنترنت e& المنزل متاحة الآن، استمتع بها الآن والاشتراك لـ 24 شهراً. | خدمة إنترنت e& للأعمال متاحة الآن، والاشتراك لـ 24 شهراً. استمتع بالإنترنت السريع المتوسع، والاعتماد على الشبكة الأصيلة في الإمارات. |

---

## Writing for audiences — Summary

This example shows how we can adapt the same message for different audiences. Flexing our voice doesn't always mean big changes. It often means small tweaks that make each audience feel heard.

### Message

> "Hello there, you haven't used your [line type] since $DATE$. Start today to keep enjoying [benefits]. Learn more [channel]."

| Audience | Tone | Example |
|---|---|---|
| **Emirati** | More polite and refined | Hello there, you haven't used your postpaid line since $DATE$. Begin today and keep enjoying the UAE's most trusted mobile network. Learn more online or in the e& app. Shukran. |
| **White Collar** | Professional and efficient | Hello there, you haven't used your postpaid line since $DATE$. Start today to keep enjoying non-stop data, GoChat, and more. Learn more in the e& app. |
| **Business** | Respectful, emphasise trust | Dear customer, you haven't used your Business Internet yet. Start today for ultra-fast internet and 24/7 support from the UAE's original network. Learn more online. |
| **Blue Collar** | Helpful and direct | Hello there, you haven't used your prepaid line since $DATE$. Start today by streaming, texting, or calling. Or switch plans in the e& app. |
| **Single Professionals** | Relevant products, flexibility | Hello there, you haven't used your prepaid line since $DATE$. Start today to keep enjoying Flexi minutes, 100 hours of free UAE Wi-Fi, and more. Or switch plans in the e& app. |
| **Youth** | More playful and energetic | Oops – you haven't used your postpaid line since $DATE$. Call, text (or stream or game) to stay connected. Want a new plan? Switch up in the e& app. |
| **Visitors** | Welcoming, short-term benefits | Hello there, you haven't used your visitor line since you arrived. Start today to explore more of the UAE. Plus, get 65% off attractions and more when you do. |

---

## Writing for journeys

*Confidential. For internal and partner use only.*

Writing for CX is writing for journeys. And at e&, there are two main types:

**Action:** a customer completes an action (eg creates an account or tracks an order), which leads to a series of steps and messages.
- Often across multiple channels and touchpoints
- Different messages for different steps
- The message is the key variable
- Our writing is responsive

**Inaction:** a customer doesn't act, which leads to a series of messages (eg payment reminders or an expiring offer).
- Often across one channel
- Often a similar message
- Our tone is the key variable
- Our writing is proactive

---

### Action journey example: Ultra Home Sports Plan

| Action/Step | Channel | Message |
|---|---|---|
| A customer buys a service… | SMS | Ahmed, thanks for choosing Ultra Home Sports Plan. You're almost up and running (or swimming). Next step: look out for our SMS to book installation. Manage order: [link] |
| …then books an installation appointment | SMS | Ahmed, your Ultra Home Sports Plan installation is booked: July 2, 16:00–20:00. One step closer to a world of more. Need to reschedule? [link] |
| …then waits for a technician | SMS | Ahmed, our technician Haider is on the way. Need to chat? Get in touch: 0561790541 |
| …then waits for the next step | SMS | Ahmed, Amazon Prime is free with Ultra Home Sports Plan. Exclusive deals, same-day delivery, and hundreds of award-winning films. Activate now via the e& app. |
| …then subscribes to Amazon Prime | Email | Subject: You're one step away… **Hi Ahmed,** You're now signed up to Amazon Prime, as part of your Ultra Home Sports Plan account. All you need to do now is activate your account for unlimited access to the UAE's largest sports channel. CTA: Activate account |
| …then activates their e& Home Services account | Email | Subject: Welcome to the home of sport **Hi Ahmed,** Thanks for activating your Ultra Home Sports Plan account. Here's what's waiting: 262+ HD channels, including dedicated sports pack. 25-device streaming. 4K TV box. And so much more. Ready? CTA: Discover Ultra Home Sports Plan |

**Arabic version:**

| الخطوة | القناة | الرسالة |
|---|---|---|
| اشترى العميل الخدمة… | SMS | أحمد، شكراً لاختيارك Ultra Home Sports. أنت على وشك الانطلاق (أو السباحة). الخطوة القادمة: انتظر SMS لحجز التركيب. إدارة الطلب: [الرابط] |
| …ثم حجز موعد التركيب | SMS | أحمد، دق حُجِّد تركيب Ultra Home Sports: 2 يوليو من 4:00 مساءً إلى 8:00 مساءً. أنت الآن أقرب إلى عالم من المزيد. هل تريد إعادة الجدولة؟ (الرابط) |
| …ثم انتظر الفني | SMS | أحمد، الفني حيدر في الطريق إليك. هل تريد الحديث معه؟ اتصل بالرقم: 0561790541 |
| …ثم انتظر الخطوة التالية | SMS | أحمد، Amazon Prime مجاناً مع Ultra Home Sports. عروض حصرية، توصيل في نفس اليوم، ومئات الأفلام الحائزة على جوائز. فعّله الآن في تطبيق e& UAE |
| …ثم اشترك في Amazon Prime | Email | الموضوع: خطوة أخرى… **أحمد،** الآن أنت مشترك في Amazon Prime مع خطة Ultra Home Sports. دق مجاناً الاشتراك. هو الآن لك عليك فعّل بحسابك للوصول غير المحدود إلى قناة الرياضات الأكبر في الإمارات. CTA: فعّل الحساب |
| …ثم فعّل حسابه في خدمات e& المنزلية | Email | الموضوع: أحمد، مرحباً في عالم الرياضة **أحمد،** شكراً لتفعيلك Ultra Home Sports. إليك ما ينتظرك: أكثر من 262 قناة HD بما في ذلك باقة رياضية مخصصة. بث لـ 25 جهاز. جهاز تلفزيون 4K. وأكثر بكثير. جاهز؟ CTA: اكتشف الآن Ultra Home Sports |

---

### Inaction journey example: Payment reminders

| Stage | Channel | Message |
|---|---|---|
| **Before due date** | Email | Subject: Your bill is due soon. **Hello [First name],** Just so you know: your bill for 200 is due on [DATE]. Pay now or set up Autopay, and have more time to enjoy more of life on the UAE's original mobile network. CTA: Pay now |
| **Due date** | Email | Subject: Please pay your bill today. **Hello [First name],** Your bill for 200 is due today. Pay now to keep enjoying the UAE's largest mobile network. CTA: Pay now |
| **After due date #1** | Email | Subject: Important: you didn't pay your bill. **[First name],** Your bill for 200 is overdue. Pay now to avoid having your account suspended, and your credit score affected. CTA: Pay now |
| **After due date #2** | Email | Subject: Important: your account is at risk. **[First name],** You still haven't paid your bill. If you don't pay within 24 hours, your account will be suspended. CTA: Pay now |
| **After due date #3** | Email | Subject: Important: account suspension. **[First name],** Your account will be suspended in 5 hours. Remember, your credit score could be negatively impacted. Pay your bill now to avoid this. CTA: Pay now |
| **After due date #4** | Email | Subject: Your services have been suspended. **[First name],** You haven't paid your bill. Your outgoing services have been suspended. Pay now to reconnect and enjoy e&. CTA: Pay now |

*Introduce a sense of urgency. Friendly and helpful → Firm but friendly, focused on benefits → Firm but now focused on consequences. A clear, short, and time-sensitive CTA across every message.*

**Arabic payment reminders:**

| المرحلة | الموضوع | الرسالة |
|---|---|---|
| قبل تاريخ الاستحقاق | فاتورة ستحق قريباً | (الاسم الأول)، تذكير بفاتورتك 200 درهم. ادفع الآن أو فعّل الدفع التلقائي. CTA: ادفع الآن |
| تاريخ الاستحقاق | يرجى دفع بفاتورتك اليوم | (الاسم الأول)، فاتورتك 200 درهم تستحق اليوم. ادفع الآن للاستمتاع بالخدمات. CTA: ادفع الآن |
| بعد الاستحقاق - 1 | هبنتي: تأخرت في دفع فاتورتك | (الاسم الأول)، فاتورتك بمبلغ 200 درهم متأخرة. ادفع الآن لتجنب تعليق الخدمة والتأثير على تصنيفك الائتماني. CTA: ادفع الآن |
| بعد الاستحقاق - 2 | هبنتي: حسابك في خطر | (الاسم الأول)، لم تدفع فاتورتك. خلال 24 ساعة يُعلَّق حسابك. CTA: ادفع الآن |
| بعد الاستحقاق - 3 | هبنتي: تعليق الحساب | (الاسم الأول)، سيُعلَّق حسابك خلال 5 ساعات. تذكّر، قد يؤثر ذلك على تصنيفك الائتماني. ادفع الآن لتجنب ذلك. CTA: ادفع الآن |
| بعد الاستحقاق - 4 | خدماتك موقوفة | (الاسم الأول)، خدماتك الصادرة تعلقت. ادفع الآن وعُد للاستمتاع بـ e&. CTA: ادفع الآن |

---

## Writing for moments

*Confidential. For internal and partner use only.*

Enriching every moment is part of our purpose. But smaller moments are harder to bring to life: there's less space, and it's more difficult to balance clarity and creativity.

If we strike the wrong balance, customers may:
- Be confused
- Feel frustrated
- Not see a way forwards
- Trust e& less

Here are some examples of getting it right.

---

### Moment examples

**Autopay (app)**

Before: Save time and hassle  
After: More time for more

Before: Enjoy peace of mind knowing that your payments are never missed and always on time. CTA: Set it up now  
After: Never miss a bill again and have more time to stream, game, and connect, with Autopay. CTA: Turn on Autopay

What's changed:
- A more inspiring subheading that connects with our tagline
- Supported by clear benefits
- Names Autopay for extra clarity, instead of using "it"
- A specific CTA with less work for the customer

**Arabic:**

قبل: توفير وقت ماها

بعد: وقت أكثر للمزيد

قبل: اشتمتع بعيش بلا قلق بشأن المدفوعات الدائمة. CTA: فعّل الآن  
بعد: لن تفوتك فاتورة أبداً للاستمتاع بالمشاهدة، والبعل، والاتصال. CTA: فعّل الدفع التلقائي

---

**Subheading (app)**

Before: What's new  
After: New for you

What's changed:
- Rhyme creates energy and personality
- More fun and less functional, without sacrificing clarity
- More personal

**Arabic:**

قبل: كل جديد أم جديد كذلك  
بعد: (همزة وداع) للتعارف الجديد

---

**Title (SMS)**

Before: Make your home smarter with the new Neo Smart Home Plan  
After: Faster, better, smarter, home

What's changed:
- More energetic
- More interesting
- More value
- Shorter, and snappier
- Cuts secondary information, like the plan's name

**Arabic:**

قبل: أكذى أعرى كذلك من Neo Smart Home Plan  
بعد: أعرى أكذى أكثر... البيت الجديد في المنزل

---

**Support field (app)**

Before: Type your issues here…  
After: How can we help?

What's changed:
- Feels more human and natural, like a conversation
- Focuses on support, not just problems
- Clear and empathetic

**Arabic:**

قبل: اكتب ها مشاكلك…  
بعد: كيف يمكننا مساعدتك؟

---

## Writing for crises

*Confidential. For internal and partner use only.*

---

### Handling difficult emotions

If something goes wrong, our customers can be angry, frustrated, or confused. In these situations, it's crucial that we:

| Do | Don't |
|---|---|
| Be empathetic: acknowledge their situation | Try and be funny |
| Write clearly and precisely | Avoid responsibility |
| Focus on facts, not opinions | Trivialise their situation, no matter how small it seems |
| Be helpful: offer a clear way forwards, and options if possible | React to aggressive language |
| Take responsibility for our mistakes | |
| Write in the first person – giving support is human | |
| Exceed their expectations | |

---

**When we're at fault — Email example**

Subject: [Customer's subject line: "recharge isn't working??!??"]

> Dear Ahmed,
>
> I'm sorry recharge didn't work for you. That shouldn't happen.
>
> I've recharged your account manually, and raised the issue with our tech team. And as an apology, I've added 1000 Smiles points to your account. If you have any more questions, I'm here to help.
>
> Thanks,  
> Sara

*Know their journey: Acknowledge their issue up front. Lead with clarity: Be clear about actions and solutions. Inspire to do more: Exceed their expectations, if possible.*

**Arabic version:**

الموضوع: تذكّر أي حدث، دق صاحب الحساب — لقد واجهت مشكلة في إعادة الشحن.

أحمد، أعتذر عن مشكلة إعادة شحن حسابك التقنية وأثرها عليك. عدل تم معالجتها مباشرةً وتنبيه فريقنا الفني. وكتعويض عن ذلك، أضفت 1000 نقطة Smiles لحسابك. إذا كان لديك أي استفسار آخر، أنا هنا لمساعدتك.

شكراً،  
سارة

---

**External situation — Email example**

Subject: Urgent: data and SMS roaming restrictions in Russia

> Dear Customer,
>
> Russia is now suspending data and SMS roaming services for 24 hours on arrival. Voice calls aren't affected. This is a mandatory suspension for all international users, which we weren't informed about beforehand.
>
> Here's what you need to know:
> - When you first connect to a Russian network, your data and SMS will be suspended for 24 hours
> - You can still make voice calls
> - If you don't use your SIM for 3 days after the suspension, Russia will apply a second 24-hour suspension
>
> What we recommend:
> - Use Wi-Fi where possible
> - Expect data and SMS outages during your stay
> - Let friends and family know about the suspension before you travel
> - Keep updated about restrictions in the e& UAE app
>
> Have questions? We're on hand to help 24/7.
>
> CTA: Contact support
>
> Thank you,  
> The e& team

**Arabic email version:**

الموضوع: تنبيه: قيود التجوال على البيانات والرسائل النصية في روسيا

عزيزي العميل،

روسيا الآن تعلّق تامد خدمات البيانات والرسائل القصيرة (SMS) للتجوال لمدة 24 ساعة عند الوصول. لا تأثير على الاتصالات الصوتية. هذا إجراء إلزامي لجميع الزوار الدوليين، ولم يتم إبلاغنا مسبقاً.

إليك ما تحتاج معرفته:
- عند الاتصال بشبكة روسية لأول مرة، سيُعلَّق بياناتك ورسائلك النصية لمدة 24 ساعة
- لا تزال تمكن إجراء المكالمات الصوتية
- إذا لم تستخدم شريحة SIM الخاصة بك لمدة 3 أيام بعد التعليق، ستطبّق روسيا تعليقاً ثانياً لمدة 24 ساعة

ما نوصي به:
- استخدم Wi-Fi أينما كان متاحاً لك
- توقّع انقطاع البيانات والرسائل النصية خلال إقامتك
- أخبر أصدقائك وعائلتك عن التعليق قبل سفرك
- تابع تحديثات القيود عبر تطبيق e& UAE

هل لديك أسئلة؟ نحن متواجدون لمساعدتك على مدار الساعة.

CTA: تواصل مع الدعم

شكراً،  
فريق e&

---

**External situation — SMS example**

> Urgent: Russia is now suspending data and SMS roaming services for 24 hours on arrival. You can still make voice calls. Learn more $LINK$

*Be clear it's urgent. Focus on the essential facts. Include a positive. When space is limited, don't try and say everything. Direct customers to somewhere they can read about the situation in full.*

**Arabic SMS:**

تنبيه: روسيا تعلّق الآن خدمات البيانات والرسائل القصيرة للتجوال لمدة 24 ساعة عند الوصول. لا تزال الاتصالات الصوتية متاحة. تعرّف على المزيد: $LINK$

---

**External situation — Push notification example**

Title: Urgent: data and SMS restrictions in Russia  
Short description: Russia is now suspending data and SMS roaming services for 24 hours on arrival. You can still make voice calls.  
Long description: We recommend using Wi-Fi where possible, and to expect outages during your stay. Learn more: $LINK$

*Be clear it's urgent. Lead with the essential facts. Like with SMS, don't try and say everything when space is limited.*

**Arabic push notification:**

العنوان: تنبيه: قيود التجوال على البيانات والرسائل النصية في روسيا  
الوصف المختصر: روسيا تعلّق الآن خدمات البيانات والرسائل القصيرة للتجوال لمدة 24 ساعة عند الوصول. لا تزال الاتصالات الصوتية متاحة.  
الوصف التفصيلي: نوصي باستخدام Wi-Fi أينما توفّر لك، وتوقّع انقطاع البيانات خلال إقامتك. تعرّف على المزيد: $LINK$

---

### Handling sensitive subjects

Difficult emotions often occur because something has gone wrong. Sensitive subjects often happen because a customer has done something wrong. In these situations, we're still clear and precise, and focus on the facts. But most importantly – we're more assertive.

**Email example — Account suspended:**

Subject: Ahmed, your account has been suspended  
[Pay now — unmissable header]

> Dear Ahmed,
>
> You haven't paid your bill, which is 55 days overdue. We've now suspended your account.
>
> This is affecting your credit score, and may affect your ability to use e& services in the future. To avoid this and reconnect with everything e&, pay now.
>
> CTA: Pay now
>
> Thanks,  
> The e& Team

*Lead with clarity: Be direct about the situation. Make the most important message unmissable, if the template allows. Know their journey: Be specific – it shows confidence and expertise. Inspire to do more: Try and end on a positive note.*

**Arabic version:**

الموضوع: أحمد، دق علّق حسابك

ادفع الآن

أحمد، لم تدفع فاتورتك لأكثر من 55 يوماً. ولذلك، دق عُلِّق حسابك.

هذا يؤثر على تصنيفك الائتماني، وقد يؤثر على قدرتك في الاستمتاع بخدمات e& مستقبلاً. تجنّب ذلك الآن واعد الاتصال، ادفع الآن فوراً.

CTA: ادفع الآن

مع الشكر،  
فريق e&

---

## Compliant communications

*Confidential. For internal and partner use only.*

Our writing must be in our voice, follow our principles, and be legally compliant. As different laws will apply to different messages and channels, the guidance on the next page is an overview of basic rules to follow.

**It is not a substitute for a legal review. If you're unsure, always check with Legal.**

| Do | |
|---|---|
| **Be truthful and transparent** | Don't exaggerate, and avoid misleading information. |
| **Write clearly** | And avoid jargon to minimise misunderstandings. |
| **Use approved templates** | If needed, ask Legal for approved disclaimers, opt-outs, legal footers, and more. |
| **Follow data privacy laws** | Check with Legal for the relevant laws to your message. |
| **Give customers an opt-out** | If needed. This is common for SMS and email, but rare for app. |
| **Use only approved product names and claims** | Don't shorten or re-label products. Only use superlatives (eg fastest) if approved. |
| **Include mandatory disclosures** | Like T&C lines, opt-outs and VAT notices, as needed. For offers, always include expiry dates and prices. |
| **Protect customer data** | Never include personal information in public-facing messages. |

---

## Writing checklist

*Confidential. For internal and partner use only.*

---

### Before writing, answer these questions:

- What channel am I writing for?
- Who am I writing for?
- What was the last step in their journey?
- What do I want them to do next?
- How do I want them to feel after reading my message?
- What's the key message I need to communicate?
- Are there any technical rules I need to follow, like character limits?

---

### Before publishing, answer these questions:

- Is my writing in the e& voice?
- Have I followed our CX writing principles?
- Is my message clear?
- Is everything legally compliant?
- Have I checked for typos, jargon, and insensitive language?
- Will my audience know what to do next?

---

## Writing with AI

*Creating, editing, and reviewing copy with LLMs*

AI is always evolving. But we do know that whatever its future, it's a part of our future. Here's our approach to writing with AI.

| We use AI to: | We don't use AI to: |
|---|---|
| Generate initial ideas for messaging based on your knowledge of e& | Write final copy from scratch, without reviewing |
| Write new copy, with you as the editor | Translate messaging into other languages, without a second opinion |
| Adapt existing messages for different audiences | Write legal copy, or any terms and conditions |
| Act as a second opinion | Create insights or points of view |
| Find different ways to say the same thing | Write for complex journeys |
| Meet technical rules, like character counts | |
| Work more efficiently | |

Writing with AI is a 2-step process:

**01** Complete the relevant briefing template (page 87–91), and enter it in the prompt field.

**02** Evaluate and refine the AI's output, using the checklist on page 93, and your intuition.

---

## Briefing templates

### Writing new copy

**AI prompt (this doesn't change):** You're writing new copy for e&. Follow the brief below and your system message.

Fill in and paste the below:

| Field | Instructions |
|---|---|
| **Objective:** | What's the core aim of this message? |
| **Context:** | Where are they on their customer journey? What messages have they already received? |
| **Audience:** | Who are you writing to? Ie Emirati/Youth/White Collar/Blue Collar/Single Professionals/Business/Unknown. How long have they been an e& customer? Are they a delinquent customer? Prepaid or postpaid? |
| **Channel:** | Which channels are you writing for? Are there any special considerations, like compliance content? |
| **Key details:** | What information must be included (eg CTA, key benefits, account info, plan name, prices, smartlinks, etc.) |
| **Other details:** | Dynamic fields (and fallbacks if not available)? Sign-off? Does it need translating? Anything else? |

*Remember: Copy and paste both the core prompt at the top of the template, and your completed brief.*

---

### Reviewing and rating existing copy

**AI prompt (this doesn't change):** You're reviewing existing copy for e&. Follow the brief below and your system message.

Highlight where and why the copy falls short of our guidelines, and give an overall percentage score of how close it is to the e& voice you know.

Fill in and paste the below:

| Field | Instructions |
|---|---|
| **Original copy:** | Paste your original copy here. |
| **Other details (optional):** | Is there anything else the AI should know? Special considerations? Has there been any customer feedback on this message? Is there anything specific you want AI to focus on? |

*Remember: Copy and paste both the core prompt at the top of the template, and your completed brief.*

---

### Evaluating AI copy

Evaluating is the last step of our process, and the most important. Never publish anything written by AI without checking that the copy:

- Follows our CX writing principles
- Follows our CX writing persona
- Considers the journey (the last step and the next)
- Reflects the audience (eg Emirati, Youth, etc.)
- Doesn't include anything unusual or dangerous (eg harmful stereotypes, misrepresentations, etc.)
- Feels human
- Is accurate
- Is clear

---

**AI Output vs Human Edit — English example:**

| | AI Output | Human Edit |
|---|---|---|
| **Title:** | Your free welcome gift is waiting | Your free welcome gift is waiting |
| **Short description:** | Claim your gift in the next 7 days. | Don't wait too long – claim in the next 7 days. |
| **Long description:** | You're in. To celebrate, we've got a free welcome gift just for you – but only for 7 days. Tap to claim yours now. | You're in. Choose from data, minutes, and more. Tap to claim now. |
| **CTA:** | Claim my gift | Claim now |

Notes:
- *Stereotypes: No gen-z stereotypes*
- *Reflects the audience: Emojis keep it playful*
- *Reflect the audience: Could be more playful*
- *Reflects the audience: Casual phrases*
- *Clarity: Could be more specific*
- *Clarity: More specific, less repetition*
- *CTA: Claim now*

---

**AI Output vs Human Edit — Arabic example:**

| | AI Output (الناتج الآلي) | Human Edit (التحرير البشري) |
|---|---|---|
| **العنوان:** | هدية ترحيبية مجانية في انتظارك | هدية ترحيبية مجانية في انتظارك |
| **الوصف المختصر:** | مكن الآن لتحصل على هديتك خلال 7 أيام. | لا تأخّر — مكن الآن لتحصل خلال 7 أيام. |
| **الوصف التفصيلي:** | أنت الآن، لمكنك احتفالنا، لدينا هدية ترحيبية مجانية خاصتك — لكن فقط لمدة 7 أيام. اضغط الآن لتحصل عليها. | أنت الآن. اختر، بيانات، دقائق، وأكثر. اضغط الآن لتحصل لتفعيل هديتك. |
| **CTA:** | احصل على هديتي | احصل عليها الآن |

---

## CX glossary

*Words and phrases we use and those we don't*

*Confidential. For internal and partner use only.*

Common situations need consistent language. It creates clarity for our customers, and familiarity for the e& brand. Here are stock phrases we use:

| Situation | Phrase |
|---|---|
| Promoting a new plan, offer, or service | Discover a world of more |
| Welcoming a customer to a new plan, offer, or service | Welcome to a world of more |
| Directing a customer to the app | …in the e& app |
| Highlighting speed in the app | …with a few taps in the e& app |
| Promoting the app | Learn and discover more in the e& app |
| Reminding a customer of an overdue payment | Important: [MESSAGE] |
| Talking about e& | …the UAE's original mobile network |
| Explaining short-term service suspension | Your services have been temporarily suspended |
| Explaining longer-term or more serious suspensions | Your services have been suspended |

---

### Word swaps

Every word affects our voice, and our customers' experience. Here are some common words used across CX, and the way we write them:

| Instead of… | Use… |
|---|---|
| Addon | Add-on |
| Assist | Help |
| Avail | Unlock |
| Commence | Start |
| Distributed workforces | Remote teams |
| Enable | Allow/Let |
| Facilitate | Help |
| Funds | Money |
| In order to | To |
| Kindly ensure | Please |
| Migrate | Switch |
| Necessary | Essential |
| Notify | Tell |
| Obtain | See/get |
| Provide | Give |
| Rental | Subscription |
| Request | Ask |
| Schedule | Book |
| Utilise | Use |
| Value-added services | Extra services |
| Yourself/myself | You/me |
| Zero-touch deployment | Auto-setup |

*If you think a word or phrase should be added to this glossary, email razad@eand.com*

---

*End of CX writing guidelines*
