# Arabic Glossary — Glossary

**Description:** Approved English-to-Arabic translations for operational and functional terms across billing, plan management, navigation, CTAs, roaming, verification, status and error messages. Includes contextual usage notes.

---

## Table of Contents

- [Roaming](#roaming)
- [Account & Contact](#account-contact)
- [Billing & Payment](#billing-payment)
- [Plan Management](#plan-management)
- [Status / Error](#status-error)
- [Benefits / Addons](#benefits-addons)
- [Actions / Operations](#actions-operations)
- [Usage & Allowances](#usage-allowances)
- [Support & Tickets](#support-tickets)
- [Navigation & CTAs](#navigation-ctas)
- [Verification](#verification)
- [Messages](#messages)
- [Complaints](#complaints)
- [Network & Connectivity](#network-connectivity)
- [Legal](#legal)
- [Uncategorized](#uncategorized)
- [Devices & SIM](#devices-sim)
- [Retail](#retail)

---

## Roaming

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Abroad | في الخارج | Refers to when a customer uses their mobile services outside the UAE. Commonly used in roaming settings or usage messages. |  |
| Eligible countries | الدول المؤهلة |  |  |
| GCC | دول مجلس التعاون الخليجي |  |  |
| Roam Like Home | تجوّل كأنك في دارك | Use local plan allowances abroad |  |
| Roaming  | تجوال |  |  |

---

## Account & Contact

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Account Number | رقم الحساب | Refers to the customer’s main mobile number associated with their account. |  |
| Additional line | خط إضافي | An extra mobile line added under the same customer account |  |
| Address | عنوان | The registered location or billing address associated with the customer’s account. |  |
| Alternate contact person | رقم اتصال بديل | A person authorized to communicate or manage the account on behalf of the main user. |  |
| Company | الشركة | the business or organization linked to the account |  |
| Contact Person Details | بيانات جهة الاتصال | Information of the person authorized to manage or receive updates for the account. |  |
| credit limit | حد الرصيد | A set llimit tht controls the maximum amount that can be charged before payment is required, including usage, services, and unbilled charged. |  |
| Email address | البريد الإلكتروني |  |  |
| Mobile number | رقم الهاتف المتحرك |  | "رقم الهاتف" could be used as a shorter variant when context clearly refers to a mobile number |
| Primary | أساسي | The main account holder or main SIM associated with the account |  |
| Provide an alternate contact in case we cannot reach you | أضف رقم اتصال بديل في حال عدم إمكانية الوصول إليك | Instruction asking the user to enter another contact person or number. |  |
| Secondary | إضافي |  |  |
| Setup account | إعداد الحساب |  |  |
| Update contact | تحديث بيانات الاتصال |  |  |

---

## Billing & Payment

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Accumulated Charges | الرسوم المتأخرة | Total unpaid charges |  |
| AED | درهم | Currency shown for prices and payments |  |
| Auto-renew | يتجدد تلقائيًا | A feature that automatically renews a plan or add-on when it expires. |  |
| Bill | فاتورة | summary of all charges during a specific period |  |
| Billing | الفواتير | Charges and invoices |  |
| Billing start month & year | تاريخ بدء الفاتورة | The month and year when billing for the service begins. |  |
| change bill settings | تغيير إعدادات الفاتورة | Option to update how or where your bills are received. |  |
| charges | رسوم | Amounts billed for services, add-ons, or purchases. |  |
| Charges will be added to your next bill | سيتم إضافة الرسوم إلى فاتورتك القادمة | Message indicating the cost will appear in the next billing cycle. |  |
| Clarify charges | توضيح الرسوم | Option to view or request more details about specific charges. |  |
| Complete Your Payment | إتمام الدفع | Prompt asking the user to finalize their payment. |  |
| credit | رصيد |  |  |
| deducted | خصم |  |  |
| e-bill | فاتورة إلكترونية |  |  |
| End date | تاريخ الانتهاء |  |  |
| Exclusive | غيرمتضمن |  |  |
| Exit fee | رسوم الخروج | Fees applied when a customer cancels a contract before its completion |  |
| Grand Total | الإجمالي | The final amount to be paid after all charges are calculated. |  |
| Inclusive | متضمن | Indicates that a cost, feature, or service is already included. |  |
| Invoice | فاتورة | A detailed statement listing charges for products or services. |  |
| Invoice number | رقم الفاتورة | Unique identifier for a specific invoice. |  |
| Manage limit for previous unpaid bills | إدارة الحد الأقصى للفواتير المستحقة |  |  |
| One time charges | رسوم لمرة واحدة |  |  |
| outstanding amount | المبلغ المتبقي | The unpaid balance that must be settled. |  |
| outstanding bill | فاتورة غير مدفوعة |  |  |
| Outstanding from previous bills | رسوم الفاتورة السابقة |  |  |
| overcharged | المبلغ الزائد | Charged more than the correct amount for a service. |  |
| Payment | الدفع | Process of paying for services, plans, or purchases. |  |
| pending dues | المبالغ المستحقة |  |  |
| Price breakdown | تفاصيل السعر | Detailed list showing how the total cost is calculated. |  |
| Prorated | على أساس تناسبي | Adjusted charge based on the number of active days in a billing period. |  |
| QTY | الكمية | Abbreviation for quantity; shows the number of items or units. |  |
| Regular price | الرسوم العادية |  |  |
| Rental | رسوم الاشتراك | Regular recurring charge for a service or plan. |  |
| Standard rates | الرسوم العادية |  |  |
| Start date | تاريخ البدء | The date when the plan, contract, or service begins. |  |
| Subtotal | المجموع |  |  |
| Total amount | الإجمالي |  |  |
| unbilled charges | الرسوم غير المفوترة  |  |  |
| Unit price | السعر للوحدة |  |  |
| unpaid bills | فواتير مستحقة |  |  |
| usage charges | رسوم الاستهلاك |  |  |
| VAT | ضريبة القيمة المضافة |  | Can be shortened to "ألضريبة" in case of character limit |
| Wrong billing charges | خطأ في الرسوم |  |  |

---

## Plan Management

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Activation date | تاريخ التفعيل | the date when a plan becomes active |  |
| change plan | تغيير الباقة | Action to switch to a different plan or package. |  |
| Duration | المدة | Length of time a plan, contract, or offer remains valid. |  |
| Migrate  | التحويل / الانتقال | Moving a customer from postpaid to prepaid or vice versa |  |
| Mobile plan | باقة الهاتف |  |  |
| Pack | باقة | An add-on or supplementary product that enhances or extends the main plan, such as data packs, voice packs and roaming packs. | Use Pack for all add-ons |
| Plan | باقة | The customer’s main subscription that defines the core service (e.g. mobile, home, business plan) | Use Plan only for the primary product the customer subscribes to. Do not use for add-ons  |
| Postpaid | خط الفاتورة | Service where usage is billed after the billing period. |  |
| Postpaid plan | باقة خط الفاتورة | Mobile plan where charges are billed monthly or after use. | do not use الباقة المفوترة |
| Prepaid | مدفوع مقدمًا | Service where you pay in advance for your usage. |  |
| Prepaid plan | الباقة المدفوعة مقدمًا | Mobile plan where you pay before using minutes, data, or SMS. |  |
| Renew | تجديد | to continue a plan or service over the next period |  |
| Renewal frequency | صلاحية التجديد | How often a plan or add-on renews automatically (e.g., daily, monthly). | صلاحية التجديد |
| Subscribe | اشتراك | Service or plan that renews on a repeated cycle. |  |
| subscription | الاشتراك |  |  |
| Third-Party | طرف ثالث | A service provided by an external company. |  |
| third-party services | مزودي الخدمة الخارجيين |  |  |
| Third-Party Subscriptions | اشتراكات الطرف الثالث | Subscriptions to external apps billed through your mobile account. |  |
| Unsubscribe | إلغاء الاشتراك | Action to stop or remove a subscription or service. |  |
| Voice plan | باقة مكالمات |  |  |

---

## Status / Error

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| active | مفعّل | Service or plan is currently in use |  |
| active | نشط | An account/line is currently valid and operational |  |
| Blacklisted | مدرج في القائمة السوداء | something is blocked or restricted, could be numbers, countries etc.. |  |
| Eligible | مؤهل |  |  |
| Error report | تقرير المشكلة |  |  |
| in progress | قيد التنفيذ |  |  |
| Incompatible Router | جهاز راوتر غير متوافق |  |  |
| Ineligible | غير مؤهل |  |  |
| Issues | مشاكل | Indicates a problem or something that needs attention. |  |
| No internet connection | لا يوجد اتصال بالإنترنت | Notification that the device is offline. |  |
| not processed | لم تتم معالجتها |  |  |
| not supported | غير مدعوم |  |  |
| not valid | غير صالح |  |  |
| On hold | فترة سماح |  |  |
| Open | نشط | ticket created and active in the system |  |
| Order Status Update | تحديث حالة الطلب | The latest progress or change in the order. |  |
| Pending | معلق | A request or process that is still being reviewed or completed. |  |
| Please check your internet connection and try again. | يرجى التحقق من شبكة الإنترنت والمحاولة مرة أخرى. |  |  |
| processed | تم معالجتها | Indicates a request or payment has been completed successfully. |  |
| Progress status | تحديث الحالة |  |  |
| Reboot Failed  | فشل إعادة التشغيل |  |  |
| Resolved | تم الحل | the issue has been addressed and solved |  |
| Service Suspended | تم إيقاف الخدمة مؤقتًا |  |  |
| Something went wrong | حدث خطأ ما | General error message indicating a temporary issue. |  |
| Sorry, unable to proceed with your order | عذرًا، لم نتمكن من معالجة طلبك. | Error message shown when the order cannot be completed. |  |
| Sorry, we are unable to continue with your order. | عذرًا، لم نتمكن من متابعة طلبك.  | Notification indicating the request cannot be processed right now. |  |
| Status | ألحالة |  |  |
| Troubleshoot | استكشاف الأخطاء وإصلاحها |  |  |
| Try again | حاول مرة أخرى |  |  |
| unable | عدم القدرة |  |  |
| unable to process | لم نتمكن من معالجة |  |  |
| Under review | قيد المراجعة | ticket is actively being reviewed by a team |  |
| wrong | خطأ |  |  |

---

## Benefits / Addons

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Active Add-ons | المزايا الإضافية المفعّلة | Add-ons that are currently enabled and active |  |
| Add-ons | مزايا إضافية | Extra services or allowances that can be added to a mobile or data plan |  |
| Benefits | المزايا | The advantages provided within a plan or offer. |  |
| cashback | استرداد نقدي | A percentage of spend returned to the customer as credit |  |
| Collaborations | تعاون | Business mobile add-ons that provides data for collaborations tools such as Microsoft Teams and Zoom |  |
| Combo | كومبو | A bundled offer combining multiple services or features. |  |
| feature | ميزة |  |  |
| uninterrupted internet | إنترنت دون انقطاع |  |  |

---

## Actions / Operations

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Adjust | تعديل | Option to change or update selected settings or details. |  |

---

## Usage & Allowances

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Allowance | رصيد | The allocated amount of data, minutes, or SMS available within a customer’s plan. |  |
| Balance | رصيد | The remaining or available amount in the account. |  |
| Bonus credit | رصيد إضافي | Extra credit added to the cutomer's balance as a promotion or reward. |  |
| Carryforward | ترحيل | Option to move unused data or minutes to a specified period |  |
| carry-over unused allowances | نقل الرصيد المتبقي | Remaining unused allowances that can be transferred to the next validity period |  |
| Data | بيانات | Refers to mobile internet usage or allowance. |  |
| Data Usage | استهلاك البيانات | Amount of mobile data used during the current period. |  |
| Flexi minutes | دقائق مرنة | Minutes that can be used for any local and international and incoming roaming calls |  |
| Incoming | واردة | Refers to calls or messages received on a line. |  |
| Insufficient Balance | رصيد غير كافٍ |  |  |
| International minutes | دقائق دولية | Minutes used for calling numbers outside the UAE. |  |
| Local minutes | دقائق محلية | Minutes used for calls within the UAE. |  |
| minimum term | الحد الأدنى لمدة الاستخدام |  |  |
| Minutes per month | الدقائق شهريًا |  |  |
| National Minutes | دقائق محلية |  |  |
| online experience | تجربة الاستخدام عبر الإنترنت |  |  |
| Outgoing | صادرة | Refers to calls, messages, or data sent from the user line. |  |
| play-on-demand data | استخدام البيانات حسب الطلب |  |  |
| Remaining Data | البيانات المتبقية | The unused portion of your data allowance. |  |
| SMS | رسالة نصية |  |  |
| transfer of funds | تحويل الأموال |  |  |
| Unlimited calls | مكالمات غير محدودة | Calls usage without a fixed limit, subject to fair usage policy. |  |
| Unlimited Data | بيانات غير محدودة | Data usage without a fixed limit, subject to fair usage policy. |  |

---

## Support & Tickets

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Attach document | إرفاق مستند | Instruction or button label used to upload a file or document to support a request. |  |
| Attachments | المرفقات | Files or documents uploaded with a support request or message. |  |
| New Support Ticket | طلب دعم جديد |  | Use "شكوى" if it refers to complaint ticket |
| order details | تفاصيل الطلب |  |  |
| order number | رقم الطلب |  |  |
| Raise request | تقديم طلب |  |  |
| Reference number | رقم المرجع | Unique number used to identify a specific request or case. |  |
| settings | إعدادات |  |  |
| support | دعم | Help service available through chat, call, or request submission. |  |
| supported formats | الصيغ المدعومة | File types allowed for upload or attachment. |  |
| Ticket | طلب | A submitted request that is being tracked by the support team. | Use "شكوى" if it refers to complaint ticket |
| Ticket details | تفاصيل الطلب | Information about the status and progress of the submitted request. |  |
| Track | تتبع |  |  |

---

## Navigation & CTAs

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Back | عودة | A button or link that returns the user to the previous page or section. |  |
| Back to account selection | العودة إلى اختيار الحسابات | Navigation option that takes the user back to the account selection screen. |  |
| Back to Order | العودة إلى الطلبات | CTA that redirects the user to the previous order page. |  |
| Buy Now | اشتر الآن | CTA button used to proceed with purchasing a product |  |
| Cancel | إلغاء | Stop or undo a request |  |
| Checkout | إتمام الطلب | Final step to confirm and complete a purchase or subscription. |  |
| Confirm | تأكيد | Step to verify or approve an action |  |
| Continue | استمرار | Button or action to proceed to the next step |  |
| Delete | حذف | Action to remove an item or cancel saved data. |  |
| Done | إنهاء | CTA used to close a completed flow or screen after a success action. Use "تم" if the user has finished input and is confirming completion of an action (e.g. form, selection) |  |
| Edit | تعديل | Option to change or update information. |  |
| Enable Location Access | السماح بالوصول إلى الموقع |  |  |
| Hide Summary | إخفاء الملخص |  |  |
| Manage | إدارة |  |  |
| Pay now | ادفع الآن | Button or action to complete a payment |  |
| Place order | تأكيد الطلب | Action to confirm and submit your purchase or subscription. |  |
| Proceed to checkout | متابعة للدفع | Button to continue to the final payment or confirmation step. |  |
| Retry | إعادة المحاولة | Button to try the previous action again. |  |
| Save | حفظ |  |  |
| Select | اختر |  |  |
| Set Preference | ضبط الإعدادات المفضلة |  |  |
| Start | ابدأ |  |  |
| Submit | إرسال | Action to confirm and send the request |  |
| Troubleshoot now | ابدأ استكشاف الأخطاء وإصلاحها |  |  |
| Update document | تحديث الملف |  |  |
| Proceed | متابعة |  |  |
| Get started | ابدأ |  |  |
| View | عرض |  |  |

---

## Verification

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Biometric scan | مسح بيومتري | Authentication method using facial or fingerprint recognition to verify identity. |  |
| Camera Permission Required | السماح بالوصول إلى الكاميرا مطلوب | System message indicating camera access is needed to proceed |  |
| Face ID capture failed | فشل التقاط بصمة الوجه |  |  |
| Face ID verefication | التحقق عبر بصمة الوجه |  |  |
| OTP | رمز التحقق OTP |  |  |
| UAE PASS | الهوية الرقمية |  |  |
| Verification in progress | جاري التحقق |  |  |
| verify | تحقق |  |  |
| Verify Face ID  | تحقّق من بصمة الوجه |  |  |

---

## Messages

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Bonus unlocked!  | تم تفعيل الرصيد الإضافي!  | Confirmation message indicating a bonus benefit has been applied or is now available |  |

---

## Complaints

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Complaint | شكوى | A formal request to report an issue or dissatisfaction. |  |
| complaint sub-type | فئة الشكوى | A specific category under the main complaint type for better tracking. |  |
| Complaint type | نوع الشكوى | Main classification used to identify the nature of a complaint. |  |
| Report | إبلاغ | Option to notify e& about an issue or concern. | when the user raises a complaint and report |

---

## Network & Connectivity

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| connection restored | استعادة الاتصال | Indicates that a previously interrupted service or connection is now active again |  |
| Disabled | معطّل |  |  |
| Ethernet | Ethernet |  | kept in Engilsh |
| Free speed boost  | سرعة إنترنت إضافية مجانية  |  |  |
| Network | شبكة |  |  |
| Offline | غير متصل |  |  |
| Online | متصل | Used to indicate connectivity status of a device or service |  |
| Paused | موقوف مؤقتًا |  |  |
| power socket | مقبس الكهرباء |  |  |
| Reboot | إعادة التشغيل |  |  |
| restore internet access | إعادة تفعيل خدمة الإنترنت |  |  |
| signal | إشارة |  |  |
| Uptime | مدة التشغيل | Uptime shows how long your router has been running without interruption. Longer uptime means better and stable performance.  |  |
| Wi-Fi | شبكة Wi-Fi |  |  |
| Wi-Fi Extender | موسّع نطاق Wi-Fi |  |  |
| Hotspot | نقطة الاتصال |  | in context, better to write as follows: "نقطة الاتصال (Hotspot)" |
| Tethering | الربط |  | in context, better to write as follows: "الربط (Tethering)" |

---

## Legal

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Contract Details | تفاصيل العقد | Information outlining the terms, conditions and key elements of the contract |  |
| Contract Duration | مدة العقد | The length of time the contract remains active before it can be changed or cancelled. |  |
| Outstanding contract duration  | مدة العقد المتبقية |  |  |
| T&C apply | تطبّق الشروط والأحكام |  |  |

---

## Uncategorized

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Eligibility | الأهلية |  |  |
| Free trial | فترة تجريبية مجانية |  |  |
| instant | فوري |  |  |
| Landline number | رقم الهاتف الثابت |  |  |
| Non-GCC Countries | الدول غير دول مجلس التعاون الخليجي |  |  |
| Online | عبر الإنترنت | Used to indicate an action performed through digital channels (e.g. recharge, payment, application) | Can be shortened to "أونلاين" in case of character limit |
| plug it back | أعد توصيله |  |  |
| Recharge | إعادة تعبئة الرصيد |  |  |
| Reschedule visit | إعادة حجز الموعد |  |  |
| Satellite Operators | مشغّلي الأقمار الصناعية |  |  |
| Schedule visit | احجز موعد الزيارة |  |  |
| Service Alert | تنبيه الخدمة |  |  |
| Service issue detected  | تم اكتشاف مشكلة في الخدمة |  |  |
| system–generated | تم إنشاؤه تلقائيًا بواسطة النظام |  |  |
| technical expert | فني مختص |  |  |
| Technical issue | مشكلة تقنية |  |  |
| unplug | افصل |  |  |
| Non-stop data | بيانات بدون توقف |  |  |
| upgrade | ترقية |  |  |
| downgrade | تخفيض |  |  |
| download | تنزيل |  |  |
| upload | تحميل |  |  |
| Installed | تم التركيب |  |  |
| Placed | تم إنشاء الطلب | When related to an order status |  |
| Assigned | تم التعيين | Context: when a scheduled appointment is assigned |  |
| Reschedule appointemnt | إعادة جدولة الموعد |  |  |
| Smart Verification | التحقّق الذكي |  |  |
| Face verification | التحقّق من بصمة الوجه |  |  |
| Identity | هوية |  |  |
| Document verification failed | فشل التحقّق من الوثيقة |  |  |
| Verification cancelled | تم إلغاء التحقّق |  |  |
| Session expired | انتهت الجلسة |  |  |
| Facial recognition | التعرّف على بصمة الوجه |  |  |
| Visa | إقامة | Use this translation when referring to a residential visa | If the context is related to UAE PASS verification/document sharing, then use this translation "إقامة" |
| Visa | تأشيرة | Use this translation when referring to a tourist visa |  |
| Verified | تم التحقّق |  |  |
| Relationship Manager | مدير العلاقات | An option under support page: Dedicated manager to support user with all  queries |  |
| Support centre | مركز المساعدة |  |  |
| Guides and support articles | الأدلة ومقالات المساعدة |  |  |
| Chat | دردشة |  |  |
| Block | حظر |  |  |
| Spam calls | المكالمات المزعجة |  |  |
| Unwanted calls | المكالمات الغير مرغوب فيها |  |  |
| DNCR | سجل عدم الاتصال (DNCR) |  |  |
| Core benefits | المزايا الأساسية |  |  |
| Frequently asked questions | الأسئلة المتكررة |  |  |
| no extra cost | دون أي تكلفة إضافية |  |  |

---

## Devices & SIM

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| eSIM replacement | استبدال شريحة eSIM | Transfer physical SIM to eSIM |  |
| Extender | موسّع النطاق |  |  |
| Multiple SIMs | شرائح SIM متعددة |  |  |
| Router | راوتر |  |  |
| SIM number | رقم شريحة SIM | The unique number printed on the SIM card used to identify it. |  |
| SIM replacement | استبدال شريحة SIM | Request to replace current SIM with an eSIM |  |
| Switch to eSIM | التبديل إلى eSIM |  |  |

---

## Retail

| Term / Phrase | Arabic Translation | Description | Notes |
|---|---|---|---|
| Sales | المبيعات |  |  |
| Store | المتجر | Physical e& retail location |  |

---
